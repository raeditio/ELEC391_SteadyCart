% Simscape(TM) Multibody(TM) version: 24.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(258).translation = [0.0 0.0 0.0];
smiData.RigidTransform(258).angle = 0.0;
smiData.RigidTransform(258).axis = [0.0 0.0 0.0];
smiData.RigidTransform(258).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 7.9999999999999929 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = "B[6x2inBreadboard-1:-:assembly of drv 8833.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [20.319057261674967 41.137955455171763 19.050470100706804];  % mm
smiData.RigidTransform(2).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(2).axis = [-1 -1.8061270805748461e-28 2.9500000000000007e-14];
smiData.RigidTransform(2).ID = "F[6x2inBreadboard-1:-:assembly of drv 8833.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 12.5 -30.000000000000014];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [7.1054273576010019e-14 -3.5527136788005009e-15 -0.20000000000000639];  % mm
smiData.RigidTransform(4).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(4).axis = [-1 -0 -0];
smiData.RigidTransform(4).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 12.5 30.000000000000014];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [5.6843418860808015e-14 -1.7763568394002505e-14 -0.20000000000000995];  % mm
smiData.RigidTransform(6).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(6).axis = [-1 -0 -0];
smiData.RigidTransform(6).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 12.5 30.000000000000014];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-1:-:pan cross head_am-48]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [34.450000000000003 5.3290705182007514e-14 -2.8421709430404007e-14];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(8).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-1:-:pan cross head_am-48]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 12.499999999999996 -30];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-5.6843418860808015e-14 -7.1054273576010019e-15 -0.20000000000000995];  % mm
smiData.RigidTransform(10).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(10).axis = [-1 -0 -0];
smiData.RigidTransform(10).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 12.499999999999996 30];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-4.2632564145606011e-14 -1.4210854715202004e-14 -0.19999999999999218];  % mm
smiData.RigidTransform(12).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(12).axis = [-1 -0 -0];
smiData.RigidTransform(12).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [72.499999999999986 30.000000000000011 0];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = "B[Acrylic Frame-4:-:PLA Battery Holder - 8xAA Horizontal Position-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-2.8421709430404007e-14 -18.850000000000012 30.000000000000011];  % mm
smiData.RigidTransform(14).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(14).axis = [0 0.70710678118654746 0.70710678118654757];
smiData.RigidTransform(14).ID = "F[Acrylic Frame-4:-:PLA Battery Holder - 8xAA Horizontal Position-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0 7.9999999999999929 0];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(15).ID = "B[6x2inBreadboard-1:-:6mm SPDT Mini Toggle Switch.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-45.577190415097398 48.193020194537482 -9.5499999999999972];  % mm
smiData.RigidTransform(16).angle = 0;  % rad
smiData.RigidTransform(16).axis = [0 0 0];
smiData.RigidTransform(16).ID = "F[6x2inBreadboard-1:-:6mm SPDT Mini Toggle Switch.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-45 -47.500000000000007 0];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(17).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(17).ID = "B[Acrylic Frame-4:-:TPU Frame Bumper - 50mm-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-44.999999999999993 37.5 3.1750000000000029];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(18).axis = [-0.57735026918962573 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(18).ID = "F[Acrylic Frame-4:-:TPU Frame Bumper - 50mm-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 0 114.29999999999998];  % mm
smiData.RigidTransform(19).angle = 0;  % rad
smiData.RigidTransform(19).axis = [0 0 0];
smiData.RigidTransform(19).ID = "B[250mm ROD-1:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-31.874679990839358 49.648814441853375 114.29999999999994];  % mm
smiData.RigidTransform(20).angle = 0;  % rad
smiData.RigidTransform(20).axis = [0 0 0];
smiData.RigidTransform(20).ID = "F[250mm ROD-1:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [0 0 114.29999999999998];  % mm
smiData.RigidTransform(21).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(21).axis = [1 0 0];
smiData.RigidTransform(21).ID = "B[250mm ROD-1:-:hex nut_ai-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [0 -7.1054273576010019e-15 222.85959999999989];  % mm
smiData.RigidTransform(22).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(22).axis = [1 0 0];
smiData.RigidTransform(22).ID = "F[250mm ROD-1:-:hex nut_ai-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(23).angle = 0;  % rad
smiData.RigidTransform(23).axis = [0 0 0];
smiData.RigidTransform(23).ID = "B[Acrylic Frame-4:-:250mm ROD-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [0 0 -108.55959999999989];  % mm
smiData.RigidTransform(24).angle = 0;  % rad
smiData.RigidTransform(24).axis = [0 0 0];
smiData.RigidTransform(24).ID = "F[Acrylic Frame-4:-:250mm ROD-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [0 0 114.3];  % mm
smiData.RigidTransform(25).angle = 0;  % rad
smiData.RigidTransform(25).axis = [0 0 0];
smiData.RigidTransform(25).ID = "B[250mm ROD-2:-:250mm ROD-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-58.803711029517608 4.8086972411443512 114.29999999999997];  % mm
smiData.RigidTransform(26).angle = 0;  % rad
smiData.RigidTransform(26).axis = [0 0 0];
smiData.RigidTransform(26).ID = "F[250mm ROD-2:-:250mm ROD-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 0 114.3];  % mm
smiData.RigidTransform(27).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(27).axis = [1 0 0];
smiData.RigidTransform(27).ID = "B[250mm ROD-2:-:hex nut_ai-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [0 0 222.85959999999994];  % mm
smiData.RigidTransform(28).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(28).axis = [1 0 0];
smiData.RigidTransform(28).ID = "F[250mm ROD-2:-:hex nut_ai-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(29).angle = 0;  % rad
smiData.RigidTransform(29).axis = [0 0 0];
smiData.RigidTransform(29).ID = "B[Acrylic Frame-4:-:250mm ROD-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [0 0 -108.55959999999996];  % mm
smiData.RigidTransform(30).angle = 0;  % rad
smiData.RigidTransform(30).axis = [0 0 0];
smiData.RigidTransform(30).ID = "F[Acrylic Frame-4:-:250mm ROD-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [0 0 -114.3];  % mm
smiData.RigidTransform(31).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(31).axis = [1 0 0];
smiData.RigidTransform(31).ID = "B[250mm ROD-3:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-154.83698063222079 -99.405781666346527 -114.29999999999997];  % mm
smiData.RigidTransform(32).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(32).axis = [1 0 0];
smiData.RigidTransform(32).ID = "F[250mm ROD-3:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [0 0 114.30000000000001];  % mm
smiData.RigidTransform(33).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(33).axis = [1 0 0];
smiData.RigidTransform(33).ID = "B[250mm ROD-3:-:hex nut_ai-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [0 0 222.8596];  % mm
smiData.RigidTransform(34).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(34).axis = [1 0 0];
smiData.RigidTransform(34).ID = "F[250mm ROD-3:-:hex nut_ai-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(35).angle = 0;  % rad
smiData.RigidTransform(35).axis = [0 0 0];
smiData.RigidTransform(35).ID = "B[Acrylic Frame-4:-:250mm ROD-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [0 0 -108.55959999999997];  % mm
smiData.RigidTransform(36).angle = 0;  % rad
smiData.RigidTransform(36).axis = [0 0 0];
smiData.RigidTransform(36).ID = "F[Acrylic Frame-4:-:250mm ROD-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 0 114.29999999999995];  % mm
smiData.RigidTransform(37).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(37).axis = [1 0 0];
smiData.RigidTransform(37).ID = "B[250mm ROD-4:-:hex nut_ai-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [0 -7.1054273576010019e-15 222.85959999999989];  % mm
smiData.RigidTransform(38).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(38).axis = [1 0 0];
smiData.RigidTransform(38).ID = "F[250mm ROD-4:-:hex nut_ai-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [-92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(39).angle = 0;  % rad
smiData.RigidTransform(39).axis = [0 0 0];
smiData.RigidTransform(39).ID = "B[Acrylic Frame-4:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [0 0 -108.55959999999995];  % mm
smiData.RigidTransform(40).angle = 0;  % rad
smiData.RigidTransform(40).axis = [0 0 0];
smiData.RigidTransform(40).ID = "F[Acrylic Frame-4:-:250mm ROD-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [72.399999999999991 15.6 0];  % mm
smiData.RigidTransform(41).angle = 0;  % rad
smiData.RigidTransform(41).axis = [0 0 0];
smiData.RigidTransform(41).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(42).angle = 0;  % rad
smiData.RigidTransform(42).axis = [0 0 0];
smiData.RigidTransform(42).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [91.599999999999994 15.6 0];  % mm
smiData.RigidTransform(43).angle = 0;  % rad
smiData.RigidTransform(43).axis = [0 0 0];
smiData.RigidTransform(43).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(44).angle = 0;  % rad
smiData.RigidTransform(44).axis = [0 0 0];
smiData.RigidTransform(44).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [72.399999999999991 -15.6 0];  % mm
smiData.RigidTransform(45).angle = 0;  % rad
smiData.RigidTransform(45).axis = [0 0 0];
smiData.RigidTransform(45).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-10]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(46).angle = 0;  % rad
smiData.RigidTransform(46).axis = [0 0 0];
smiData.RigidTransform(46).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-10]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [91.599999999999994 -15.6 0];  % mm
smiData.RigidTransform(47).angle = 0;  % rad
smiData.RigidTransform(47).axis = [0 0 0];
smiData.RigidTransform(47).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-11]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(48).angle = 0;  % rad
smiData.RigidTransform(48).axis = [0 0 0];
smiData.RigidTransform(48).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-11]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-91.599999999999994 -15.6 0];  % mm
smiData.RigidTransform(49).angle = 0;  % rad
smiData.RigidTransform(49).axis = [0 0 0];
smiData.RigidTransform(49).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(50).angle = 0;  % rad
smiData.RigidTransform(50).axis = [0 0 0];
smiData.RigidTransform(50).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [-72.399999999999991 -15.6 0];  % mm
smiData.RigidTransform(51).angle = 0;  % rad
smiData.RigidTransform(51).axis = [0 0 0];
smiData.RigidTransform(51).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-13]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(52).angle = 0;  % rad
smiData.RigidTransform(52).axis = [0 0 0];
smiData.RigidTransform(52).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-13]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [-91.599999999999994 15.6 0];  % mm
smiData.RigidTransform(53).angle = 0;  % rad
smiData.RigidTransform(53).axis = [0 0 0];
smiData.RigidTransform(53).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-14]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(54).angle = 0;  % rad
smiData.RigidTransform(54).axis = [0 0 0];
smiData.RigidTransform(54).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-14]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [-72.399999999999991 15.6 0];  % mm
smiData.RigidTransform(55).angle = 0;  % rad
smiData.RigidTransform(55).axis = [0 0 0];
smiData.RigidTransform(55).ID = "B[Acrylic Frame-4:-:hex nut style 1_am-15]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [0 0 -8.7499999999999982];  % mm
smiData.RigidTransform(56).angle = 0;  % rad
smiData.RigidTransform(56).axis = [0 0 0];
smiData.RigidTransform(56).ID = "F[Acrylic Frame-4:-:hex nut style 1_am-15]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [0 0 0];  % mm
smiData.RigidTransform(57).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(57).axis = [1 0 0];
smiData.RigidTransform(57).ID = "B[Acrylic Frame-4:-:hex nut_ai-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [92.000000000000028 -29.5 0];  % mm
smiData.RigidTransform(58).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(58).axis = [1 0 0];
smiData.RigidTransform(58).ID = "F[Acrylic Frame-4:-:hex nut_ai-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [0 0 0];  % mm
smiData.RigidTransform(59).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(59).axis = [1 0 0];
smiData.RigidTransform(59).ID = "B[Acrylic Frame-4:-:hex nut_ai-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [92.000000000000028 29.499999999999986 0];  % mm
smiData.RigidTransform(60).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(60).axis = [1 0 0];
smiData.RigidTransform(60).ID = "F[Acrylic Frame-4:-:hex nut_ai-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [0 0 0];  % mm
smiData.RigidTransform(61).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(61).axis = [1 0 0];
smiData.RigidTransform(61).ID = "B[Acrylic Frame-4:-:hex nut_ai-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [-92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(62).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(62).axis = [1 0 0];
smiData.RigidTransform(62).ID = "F[Acrylic Frame-4:-:hex nut_ai-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [0 0 0];  % mm
smiData.RigidTransform(63).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(63).axis = [1 0 0];
smiData.RigidTransform(63).ID = "B[Acrylic Frame-4:-:hex nut_ai-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(64).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(64).axis = [1 0 0];
smiData.RigidTransform(64).ID = "F[Acrylic Frame-4:-:hex nut_ai-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [-92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(65).angle = 0;  % rad
smiData.RigidTransform(65).axis = [0 0 0];
smiData.RigidTransform(65).ID = "B[Acrylic Frame-4:-:Acrylic Frame-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [-92.000000000000028 -29.499999999999993 -51.349999999999994];  % mm
smiData.RigidTransform(66).angle = 0;  % rad
smiData.RigidTransform(66).axis = [0 0 0];
smiData.RigidTransform(66).ID = "F[Acrylic Frame-4:-:Acrylic Frame-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [72.5 -29.999999999999986 0];  % mm
smiData.RigidTransform(67).angle = 0;  % rad
smiData.RigidTransform(67).axis = [0 0 0];
smiData.RigidTransform(67).ID = "B[Acrylic Frame-4:-:pan cross head_am-45]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [3.0999999999999988 0 -4.4408920985006262e-16];  % mm
smiData.RigidTransform(68).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(68).axis = [0.57735026918962584 0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(68).ID = "F[Acrylic Frame-4:-:pan cross head_am-45]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [72.499999999999986 30.000000000000011 0];  % mm
smiData.RigidTransform(69).angle = 0;  % rad
smiData.RigidTransform(69).axis = [0 0 0];
smiData.RigidTransform(69).ID = "B[Acrylic Frame-4:-:pan cross head_am-46]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [3.0999999999999988 0 -4.4408920985006262e-16];  % mm
smiData.RigidTransform(70).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(70).axis = [0.57735026918962584 0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(70).ID = "F[Acrylic Frame-4:-:pan cross head_am-46]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [-72.500000000000014 30 0];  % mm
smiData.RigidTransform(71).angle = 0;  % rad
smiData.RigidTransform(71).axis = [0 0 0];
smiData.RigidTransform(71).ID = "B[Acrylic Frame-4:-:pan cross head_am-47]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(72).translation = [3.0999999999999988 0 -4.4408920985006262e-16];  % mm
smiData.RigidTransform(72).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(72).axis = [0.57735026918962584 0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(72).ID = "F[Acrylic Frame-4:-:pan cross head_am-47]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(73).translation = [0 0 0];  % mm
smiData.RigidTransform(73).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(73).axis = [1 0 0];
smiData.RigidTransform(73).ID = "B[Acrylic Frame-4:-:pan cross head_am-48]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(74).translation = [3.0999999999999801 76.363174370521577 18.025415392087915];  % mm
smiData.RigidTransform(74).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(74).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(74).ID = "F[Acrylic Frame-4:-:pan cross head_am-48]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(75).translation = [0 0 0];  % mm
smiData.RigidTransform(75).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(75).axis = [1 0 0];
smiData.RigidTransform(75).ID = "B[Acrylic Frame-4:-:Motor 37D-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(76).translation = [-100 -20.800000000000612 1.7763568394002505e-14];  % mm
smiData.RigidTransform(76).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(76).axis = [-1 8.3266726846886691e-17 8.3266726846886691e-17];
smiData.RigidTransform(76).ID = "F[Acrylic Frame-4:-:Motor 37D-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(77).translation = [0 0 6.3499999999999996];  % mm
smiData.RigidTransform(77).angle = 0;  % rad
smiData.RigidTransform(77).axis = [0 0 0];
smiData.RigidTransform(77).ID = "B[Acrylic Frame-4:-:PLA Thread Rod Spacer - 45mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(78).translation = [79.491893007911443 -54.91164672470461 -22.5];  % mm
smiData.RigidTransform(78).angle = 0;  % rad
smiData.RigidTransform(78).axis = [0 0 0];
smiData.RigidTransform(78).ID = "F[Acrylic Frame-4:-:PLA Thread Rod Spacer - 45mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(79).translation = [92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(79).angle = 0;  % rad
smiData.RigidTransform(79).axis = [0 0 0];
smiData.RigidTransform(79).ID = "B[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(80).translation = [0 0 22.499999999999993];  % mm
smiData.RigidTransform(80).angle = 0;  % rad
smiData.RigidTransform(80).axis = [0 0 0];
smiData.RigidTransform(80).ID = "F[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(81).translation = [0 0 6.3500000000000014];  % mm
smiData.RigidTransform(81).angle = 0;  % rad
smiData.RigidTransform(81).axis = [0 0 0];
smiData.RigidTransform(81).ID = "B[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(82).translation = [78.865588124498686 -55.807427908629961 22.499999999999972];  % mm
smiData.RigidTransform(82).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(82).axis = [1 0 0];
smiData.RigidTransform(82).ID = "F[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(83).translation = [0 0 6.3500000000000014];  % mm
smiData.RigidTransform(83).angle = 0;  % rad
smiData.RigidTransform(83).axis = [0 0 0];
smiData.RigidTransform(83).ID = "B[Acrylic Frame-5:-:6x2inBreadboard-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(84).translation = [82.250000000000014 1.0658141036401503e-14 26.999999999999975];  % mm
smiData.RigidTransform(84).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(84).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(84).ID = "F[Acrylic Frame-5:-:6x2inBreadboard-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(85).translation = [-8.4000000000000039 -20.799999999999997 -15.599999999999993];  % mm
smiData.RigidTransform(85).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(85).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(85).ID = "B[Motor 37D-1:-:pan cross head_am-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(86).translation = [4.3999999999993866 7.1054273576010019e-15 -8.8817841970012523e-16];  % mm
smiData.RigidTransform(86).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(86).axis = [0.57735026918962573 0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(86).ID = "F[Motor 37D-1:-:pan cross head_am-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(87).translation = [-27.29999999999999 -20.799999999999997 -15.599999999999989];  % mm
smiData.RigidTransform(87).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(87).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(87).ID = "B[Motor 37D-1:-:pan cross head_am-13]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(88).translation = [4.3999999999993795 1.7763568394002505e-15 -1.4210854715202004e-14];  % mm
smiData.RigidTransform(88).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(88).axis = [0.57735026918962573 0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(88).ID = "F[Motor 37D-1:-:pan cross head_am-13]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(89).translation = [-27.29999999999999 -20.800000000000004 15.600000000000007];  % mm
smiData.RigidTransform(89).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(89).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(89).ID = "B[Motor 37D-1:-:pan cross head_am-14]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(90).translation = [4.3999999999993973 0 1.3322676295501878e-14];  % mm
smiData.RigidTransform(90).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(90).axis = [0.57735026918962573 0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(90).ID = "F[Motor 37D-1:-:pan cross head_am-14]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(91).translation = [-8.4000000000000039 -20.800000000000004 15.600000000000007];  % mm
smiData.RigidTransform(91).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(91).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(91).ID = "B[Motor 37D-1:-:pan cross head_am-15]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(92).translation = [4.3999999999993973 -1.7763568394002505e-15 -8.8817841970012523e-16];  % mm
smiData.RigidTransform(92).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(92).axis = [0.57735026918962573 0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(92).ID = "F[Motor 37D-1:-:pan cross head_am-15]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(93).translation = [-27.29999999999999 -20.799999999999997 -15.599999999999989];  % mm
smiData.RigidTransform(93).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(93).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(93).ID = "B[Motor 37D-3:-:pan cross head_am-16]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(94).translation = [4.3999999999993777 -5.1351505691650867e-15 -1.5099033134902129e-14];  % mm
smiData.RigidTransform(94).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(94).axis = [0.57735026918962595 0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(94).ID = "F[Motor 37D-3:-:pan cross head_am-16]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(95).translation = [-8.4000000000000039 -20.799999999999997 -15.599999999999993];  % mm
smiData.RigidTransform(95).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(95).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(95).ID = "B[Motor 37D-3:-:pan cross head_am-17]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(96).translation = [4.3999999999993777 -5.1351505691650867e-15 -1.5099033134902129e-14];  % mm
smiData.RigidTransform(96).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(96).axis = [0.57735026918962595 0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(96).ID = "F[Motor 37D-3:-:pan cross head_am-17]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(97).translation = [-8.4000000000000039 -20.800000000000004 15.600000000000007];  % mm
smiData.RigidTransform(97).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(97).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(97).ID = "B[Motor 37D-3:-:pan cross head_am-18]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(98).translation = [4.3999999999993955 -1.5824368903645775e-15 -1.5099033134902129e-14];  % mm
smiData.RigidTransform(98).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(98).axis = [0.57735026918962595 0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(98).ID = "F[Motor 37D-3:-:pan cross head_am-18]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(99).translation = [-27.29999999999999 -20.800000000000004 15.600000000000007];  % mm
smiData.RigidTransform(99).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(99).axis = [0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(99).ID = "B[Motor 37D-3:-:pan cross head_am-19]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(100).translation = [4.3999999999993991 -5.1351505691650835e-15 0];  % mm
smiData.RigidTransform(100).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(100).axis = [0.57735026918962595 0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(100).ID = "F[Motor 37D-3:-:pan cross head_am-19]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(101).translation = [-120.00000000000001 8.6727334274277137 -23.922669101045411];  % mm
smiData.RigidTransform(101).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(101).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(101).ID = "B[:-:pan cross head_am-20]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(102).translation = [2.3999999999999915 0 7.1054273576010019e-15];  % mm
smiData.RigidTransform(102).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(102).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(102).ID = "F[:-:pan cross head_am-20]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(103).translation = [-120.00000000000001 -7.6942337707593067 -22.227857980752059];  % mm
smiData.RigidTransform(103).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(103).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(103).ID = "B[:-:pan cross head_am-22]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(104).translation = [2.3999999999999915 -1.7763568394002505e-15 -7.1054273576010019e-15];  % mm
smiData.RigidTransform(104).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(104).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(104).ID = "F[:-:pan cross head_am-22]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(105).translation = [-120.00000000000001 -8.6727334272862482 -31.677330898443117];  % mm
smiData.RigidTransform(105).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(105).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(105).ID = "B[:-:pan cross head_am-23]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(106).translation = [2.3999999999999915 1.7763568394002505e-15 0];  % mm
smiData.RigidTransform(106).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(106).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(106).ID = "F[:-:pan cross head_am-23]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(107).translation = [-120.00000000000001 7.6942337709007749 -33.372142018736469];  % mm
smiData.RigidTransform(107).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(107).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(107).ID = "B[:-:pan cross head_am-25]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(108).translation = [2.3999999999999915 -8.8817841970012523e-16 0];  % mm
smiData.RigidTransform(108).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(108).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(108).ID = "F[:-:pan cross head_am-25]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(109).translation = [120.00000000000001 0.97849965659768234 -18.350527082053212];  % mm
smiData.RigidTransform(109).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(109).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(109).ID = "B[:-:pan cross head_am-26]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(110).translation = [2.3999999999999924 9.4074384822779983e-15 1.4626161471565124e-14];  % mm
smiData.RigidTransform(110).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(110).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(110).ID = "F[:-:pan cross head_am-26]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(111).translation = [120.00000000000001 7.694233770900774 -33.372142018736469];  % mm
smiData.RigidTransform(111).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(111).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(111).ID = "B[:-:pan cross head_am-28]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(112).translation = [2.3999999999999924 2.0298615824615675e-14 6.8731907546794959e-15];  % mm
smiData.RigidTransform(112).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(112).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(112).ID = "F[:-:pan cross head_am-28]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(113).translation = [120.00000000000001 -0.9784996564562104 -37.249472917435313];  % mm
smiData.RigidTransform(113).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(113).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(113).ID = "B[:-:pan cross head_am-29]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(114).translation = [2.3999999999999924 -2.4123754221301603e-15 6.0188604699910623e-15];  % mm
smiData.RigidTransform(114).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(114).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(114).ID = "F[:-:pan cross head_am-29]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(115).translation = [120.00000000000001 -7.6942337707593058 -22.227857980752059];  % mm
smiData.RigidTransform(115).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(115).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(115).ID = "B[:-:pan cross head_am-31]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(116).translation = [2.4000000000000208 1.1819857713749977e-14 2.7395099210292537e-14];  % mm
smiData.RigidTransform(116).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(116).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(116).ID = "F[:-:pan cross head_am-31]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(117).translation = [0 -13.423393758658799 -7.7499999999999973];  % mm
smiData.RigidTransform(117).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(117).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(117).ID = "B[Motor 37D-3:-:pan cross head_am-33]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(118).translation = [2.3999999999999915 -3.5527136788005009e-15 -6.1550764485218679e-13];  % mm
smiData.RigidTransform(118).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(118).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(118).ID = "F[Motor 37D-3:-:pan cross head_am-33]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(119).translation = [0 -13.423393758658769 7.7500000000000675];  % mm
smiData.RigidTransform(119).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(119).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(119).ID = "B[Motor 37D-3:-:pan cross head_am-34]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(120).translation = [2.3999999999999915 -3.5527136788005009e-15 -6.0751403907488566e-13];  % mm
smiData.RigidTransform(120).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(120).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(120).ID = "F[Motor 37D-3:-:pan cross head_am-34]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(121).translation = [0 1.0580425424677742e-13 15.5];  % mm
smiData.RigidTransform(121).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(121).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(121).ID = "B[Motor 37D-3:-:pan cross head_am-35]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(122).translation = [2.3999999999999915 -3.5527136788005009e-15 -6.0751403907488566e-13];  % mm
smiData.RigidTransform(122).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(122).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(122).ID = "F[Motor 37D-3:-:pan cross head_am-35]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(123).translation = [0 -1.720845688168993e-15 -15.5];  % mm
smiData.RigidTransform(123).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(123).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(123).ID = "B[Motor 37D-3:-:pan cross head_am-36]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(124).translation = [2.3999999999999915 -1.7763568394002505e-15 -6.0751403907488566e-13];  % mm
smiData.RigidTransform(124).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(124).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(124).ID = "F[Motor 37D-3:-:pan cross head_am-36]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(125).translation = [0 13.423393758658797 -7.7499999999999947];  % mm
smiData.RigidTransform(125).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(125).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(125).ID = "B[Motor 37D-3:-:pan cross head_am-37]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(126).translation = [2.3999999999999915 -2.6645352591003757e-15 -6.1106675275368616e-13];  % mm
smiData.RigidTransform(126).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(126).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(126).ID = "F[Motor 37D-3:-:pan cross head_am-37]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(127).translation = [0 13.423393758658866 7.7499999999998694];  % mm
smiData.RigidTransform(127).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(127).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(127).ID = "B[Motor 37D-3:-:pan cross head_am-38]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(128).translation = [2.3999999999999915 0 -5.9685589803848416e-13];  % mm
smiData.RigidTransform(128).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(128).axis = [-0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(128).ID = "F[Motor 37D-3:-:pan cross head_am-38]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(129).translation = [0 -13.423393758658799 -7.7499999999999964];  % mm
smiData.RigidTransform(129).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(129).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(129).ID = "B[Motor 37D-1:-:pan cross head_am-39]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(130).translation = [2.3999999999999924 -5.652210898099674e-13 -2.3457546256351328e-13];  % mm
smiData.RigidTransform(130).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(130).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(130).ID = "F[Motor 37D-1:-:pan cross head_am-39]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(131).translation = [0 -1.720845688168993e-15 -15.5];  % mm
smiData.RigidTransform(131).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(131).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(131).ID = "B[Motor 37D-1:-:pan cross head_am-40]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(132).translation = [2.3999999999999782 -5.6043840746997556e-13 -2.3452146361778923e-13];  % mm
smiData.RigidTransform(132).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(132).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(132).ID = "F[Motor 37D-1:-:pan cross head_am-40]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(133).translation = [0 13.423393758658804 -7.7499999999999938];  % mm
smiData.RigidTransform(133).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(133).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(133).ID = "B[Motor 37D-1:-:pan cross head_am-41]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(134).translation = [2.4000000000000066 -5.557983008193389e-13 -2.3644836767294883e-13];  % mm
smiData.RigidTransform(134).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(134).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(134).ID = "F[Motor 37D-1:-:pan cross head_am-41]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(135).translation = [0 13.423393758658866 7.7499999999998703];  % mm
smiData.RigidTransform(135).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(135).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(135).ID = "B[Motor 37D-1:-:pan cross head_am-42]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(136).translation = [2.4000000000000066 -5.5647660146820815e-13 -2.3480661499649975e-13];  % mm
smiData.RigidTransform(136).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(136).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(136).ID = "F[Motor 37D-1:-:pan cross head_am-42]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(137).translation = [0 1.0580425424677742e-13 15.5];  % mm
smiData.RigidTransform(137).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(137).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(137).ID = "B[Motor 37D-1:-:pan cross head_am-43]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(138).translation = [2.3999999999999782 -5.6043840746997556e-13 -2.3452146361778923e-13];  % mm
smiData.RigidTransform(138).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(138).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(138).ID = "F[Motor 37D-1:-:pan cross head_am-43]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(139).translation = [0 -13.423393758658769 7.7500000000000684];  % mm
smiData.RigidTransform(139).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(139).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(139).ID = "B[Motor 37D-1:-:pan cross head_am-44]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(140).translation = [2.3999999999999924 -5.6241931047085926e-13 -2.3437888792843389e-13];  % mm
smiData.RigidTransform(140).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(140).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(140).ID = "F[Motor 37D-1:-:pan cross head_am-44]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(141).translation = [20.000000000000004 6.9999999997442597 7.0728062295799545e-11];  % mm
smiData.RigidTransform(141).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(141).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(141).ID = "B[Motor 37D-1:-:Wheel Asssembly-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(142).translation = [28.611898726034998 -4.9999999999999991 12.329117285283083];  % mm
smiData.RigidTransform(142).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(142).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(142).ID = "F[Motor 37D-1:-:Wheel Asssembly-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(143).translation = [20.000000000000004 6.9999999997442597 -2.9999999999292721];  % mm
smiData.RigidTransform(143).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(143).axis = [0.57735026918962584 0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(143).ID = "B[Motor 37D-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(144).translation = [120 -2.999999999929269 -27.799999999744873];  % mm
smiData.RigidTransform(144).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(144).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(144).ID = "F[Motor 37D-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(145).translation = [0 0 22.499999999999989];  % mm
smiData.RigidTransform(145).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(145).axis = [1 0 0];
smiData.RigidTransform(145).ID = "B[PLA Thread Rod Spacer - 45mm-1:-:PLA Thread Rod Spacer - 45mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(146).translation = [-2.2759045713812803e-14 1.8447398273931209e-14 -58.84999999999998];  % mm
smiData.RigidTransform(146).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(146).axis = [1 0 0];
smiData.RigidTransform(146).ID = "F[PLA Thread Rod Spacer - 45mm-1:-:PLA Thread Rod Spacer - 45mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(147).translation = [0 7.9999999999999929 0];  % mm
smiData.RigidTransform(147).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(147).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(147).ID = "B[6x2inBreadboard-1:-:Arduino Nano 33 IoT.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(148).translation = [-16.588938626169824 -0.79999999999997584 -26.999999999999975];  % mm
smiData.RigidTransform(148).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(148).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(148).ID = "F[6x2inBreadboard-1:-:Arduino Nano 33 IoT.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(149).translation = [92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(149).angle = 0;  % rad
smiData.RigidTransform(149).axis = [0 0 0];
smiData.RigidTransform(149).ID = "B[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(150).translation = [0 0 -12.090399999999988];  % mm
smiData.RigidTransform(150).angle = 0;  % rad
smiData.RigidTransform(150).axis = [0 0 0];
smiData.RigidTransform(150).ID = "F[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(151).translation = [92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(151).angle = 0;  % rad
smiData.RigidTransform(151).axis = [0 0 0];
smiData.RigidTransform(151).ID = "B[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-6]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(152).translation = [0 0 -12.090399999999988];  % mm
smiData.RigidTransform(152).angle = 0;  % rad
smiData.RigidTransform(152).axis = [0 0 0];
smiData.RigidTransform(152).ID = "F[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-6]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(153).translation = [-92.000000000000028 29.499999999999993 0];  % mm
smiData.RigidTransform(153).angle = 0;  % rad
smiData.RigidTransform(153).axis = [0 0 0];
smiData.RigidTransform(153).ID = "B[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(154).translation = [0 0 -12.090399999999988];  % mm
smiData.RigidTransform(154).angle = 0;  % rad
smiData.RigidTransform(154).axis = [0 0 0];
smiData.RigidTransform(154).ID = "F[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(155).translation = [-92.000000000000028 -29.499999999999993 0];  % mm
smiData.RigidTransform(155).angle = 0;  % rad
smiData.RigidTransform(155).axis = [0 0 0];
smiData.RigidTransform(155).ID = "B[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(156).translation = [0 0 -12.090399999999988];  % mm
smiData.RigidTransform(156).angle = 0;  % rad
smiData.RigidTransform(156).axis = [0 0 0];
smiData.RigidTransform(156).ID = "F[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(157).translation = [-99.999999999999986 -37.500000000000007 6.3499999999999996];  % mm
smiData.RigidTransform(157).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(157).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(157).ID = "B[Acrylic Frame-4:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(158).translation = [-99.999999999999986 -37.500000000000007 -126.34999999999999];  % mm
smiData.RigidTransform(158).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(158).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(158).ID = "F[Acrylic Frame-4:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(159).translation = [-100.00000000000001 37.499999999999993 6.3500000000000014];  % mm
smiData.RigidTransform(159).angle = 0;  % rad
smiData.RigidTransform(159).axis = [0 0 0];
smiData.RigidTransform(159).ID = "B[Acrylic Frame-5:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(160).translation = [-100.00000000000001 37.499999999999993 -75];  % mm
smiData.RigidTransform(160).angle = 0;  % rad
smiData.RigidTransform(160).axis = [0 0 0];
smiData.RigidTransform(160).ID = "F[Acrylic Frame-5:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(161).translation = [0 0 0];  % mm
smiData.RigidTransform(161).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(161).axis = [1 0 0];
smiData.RigidTransform(161).ID = "B[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:PLA Thread Rod Spacer - 45mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(162).translation = [78.865588124498743 -55.807427908629954 22.500000000000014];  % mm
smiData.RigidTransform(162).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(162).axis = [1 0 0];
smiData.RigidTransform(162).ID = "F[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:PLA Thread Rod Spacer - 45mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(163).translation = [0 0 6.3499999999999996];  % mm
smiData.RigidTransform(163).angle = 0;  % rad
smiData.RigidTransform(163).axis = [0 0 0];
smiData.RigidTransform(163).ID = "B[Acrylic Frame-4:-:AA Battery Mock-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(164).translation = [0 0 -9.5000000000000036];  % mm
smiData.RigidTransform(164).angle = 0;  % rad
smiData.RigidTransform(164).axis = [0 0 0];
smiData.RigidTransform(164).ID = "F[Acrylic Frame-4:-:AA Battery Mock-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(165).translation = [-9.0000000000000071 0 0];  % mm
smiData.RigidTransform(165).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(165).axis = [0.57735026918962584 0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(165).ID = "B[PLA Battery Holder - 8xAA Horizontal Position-2:-:PLA Puser - 8xAA Battery Holder-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(166).translation = [-2.5505869972228665e-15 2.8421709430404007e-14 -1.3980089331122914e-14];  % mm
smiData.RigidTransform(166).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(166).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(166).ID = "F[PLA Battery Holder - 8xAA Horizontal Position-2:-:PLA Puser - 8xAA Battery Holder-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(167).translation = [-5.7400000000000091 1.0000000000000009 -13.5];  % mm
smiData.RigidTransform(167).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(167).axis = [0 1 0];
smiData.RigidTransform(167).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07100KL Resistor_1.stp-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(168).translation = [-4.640000000000005 1.0000000000000009 10.73];  % mm
smiData.RigidTransform(168).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(168).axis = [-0 -1 -0];
smiData.RigidTransform(168).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07100KL Resistor_1.stp-6]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(169).translation = [5.0899999999999972 1.0000000000000009 -1.8999999999999999];  % mm
smiData.RigidTransform(169).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(169).axis = [0 1 0];
smiData.RigidTransform(169).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-071KL Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(170).translation = [4.6650000000000027 0.98499999999999976 9.7250000000009997];  % mm
smiData.RigidTransform(170).angle = 0;  % rad
smiData.RigidTransform(170).axis = [0 0 0];
smiData.RigidTransform(170).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:AC0402JR-0724KL Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(171).translation = [4.6650000000000027 0.98499999999999976 8.7249999999970012];  % mm
smiData.RigidTransform(171).angle = 0;  % rad
smiData.RigidTransform(171).axis = [0 0 0];
smiData.RigidTransform(171).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:AC0402JR-0775KL Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(172).translation = [0 1.6499999999999986 0];  % mm
smiData.RigidTransform(172).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(172).axis = [-0 -1 -0];
smiData.RigidTransform(172).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:Reser Button_1.stp-1:User Library-arduino_nano_reset shell_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(173).translation = [0 0 0];  % mm
smiData.RigidTransform(173).angle = 0;  % rad
smiData.RigidTransform(173).axis = [0 0 0];
smiData.RigidTransform(173).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:Reser Button_1.stp-1:User Library-arduino_nano_reset core_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(174).translation = [0 0.80000000000000904 10.91];  % mm
smiData.RigidTransform(174).angle = 0;  % rad
smiData.RigidTransform(174).axis = [0 0 0];
smiData.RigidTransform(174).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:Reser Button_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(175).translation = [-5.8099999999999961 0.80000000000000904 20.100000000000005];  % mm
smiData.RigidTransform(175).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(175).axis = [-0 -1 -0];
smiData.RigidTransform(175).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:HSMG-C190 LED_1.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(176).translation = [-1.7000000000000002 2.0000000000000018 0];  % mm
smiData.RigidTransform(176).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(176).axis = [-0 -1 -0];
smiData.RigidTransform(176).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:NINA-W102 Module_1.stp-1:NINA-W102 Cover.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(177).translation = [0 0 0];  % mm
smiData.RigidTransform(177).angle = 0;  % rad
smiData.RigidTransform(177).axis = [0 0 0];
smiData.RigidTransform(177).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:NINA-W102 Module_1.stp-1:NINA-W102 Body_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(178).translation = [7.0000000000000009 0.79999999999999516 0];  % mm
smiData.RigidTransform(178).angle = 0;  % rad
smiData.RigidTransform(178).axis = [0 0 0];
smiData.RigidTransform(178).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:NINA-W102 Module_1.stp-1:NINA-W102 Antenna_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(179).translation = [0 0.84999999999998965 -14.5];  % mm
smiData.RigidTransform(179).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(179).axis = [0 1 0];
smiData.RigidTransform(179).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:NINA-W102 Module_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(180).translation = [5.7900000000000036 0.80000000000000904 19.600000000000001];  % mm
smiData.RigidTransform(180).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(180).axis = [-0 -1 -0];
smiData.RigidTransform(180).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:HSMG-C190 LED_1.stp-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(181).translation = [-1.2100000000000026 0.82000000000000128 -0.24000000000000005];  % mm
smiData.RigidTransform(181).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(181).axis = [0 1 0];
smiData.RigidTransform(181).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:atmegaSAMD21_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(182).translation = [-3.7900000000000018 1.0499999999999954 5.1000000000000005];  % mm
smiData.RigidTransform(182).angle = 0;  % rad
smiData.RigidTransform(182).axis = [0 0 0];
smiData.RigidTransform(182).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-17]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(183).translation = [-5.6599999999999984 1.0499999999999954 -4.3499999999999996];  % mm
smiData.RigidTransform(183).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(183).axis = [0 1 0];
smiData.RigidTransform(183).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-15]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(184).translation = [5.5824999999999969 1.0499999999999954 -17.512499999999996];  % mm
smiData.RigidTransform(184).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(184).axis = [0 1 0];
smiData.RigidTransform(184).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(185).translation = [0 0 0];  % mm
smiData.RigidTransform(185).angle = 0;  % rad
smiData.RigidTransform(185).axis = [0 0 0];
smiData.RigidTransform(185).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:Nano_33IoT Body_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(186).translation = [5.3850000000000007 1.0500000000000091 14.762499999999999];  % mm
smiData.RigidTransform(186).angle = 0;  % rad
smiData.RigidTransform(186).axis = [0 0 0];
smiData.RigidTransform(186).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(187).translation = [-0.4099999999999937 1.4500000000000068 14.77];  % mm
smiData.RigidTransform(187).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(187).axis = [0 1 0];
smiData.RigidTransform(187).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:PRTR5V0U2X Protection Diode_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(188).translation = [2.4150000000000005 1.4250000000000096 15.1325];  % mm
smiData.RigidTransform(188).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(188).axis = [-0 -1 -0];
smiData.RigidTransform(188).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:C0805C472KDRACTU Capacitor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(189).translation = [-1.5199999999999936 1.0499999999999954 -6.46];  % mm
smiData.RigidTransform(189).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(189).axis = [0 1 0];
smiData.RigidTransform(189).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-14]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(190).translation = [5.3849999999999936 1.0500000000000091 15.737500000000004];  % mm
smiData.RigidTransform(190).angle = 0;  % rad
smiData.RigidTransform(190).axis = [0 0 0];
smiData.RigidTransform(190).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-13]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(191).translation = [-4.0349999999999966 0.79999999999999516 -6.0800000000000001];  % mm
smiData.RigidTransform(191).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(191).axis = [0 1 0];
smiData.RigidTransform(191).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:ATECC608A No Lead Crypto Auth_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(192).translation = [3.6900000000000057 1.6499999999999986 6.25];  % mm
smiData.RigidTransform(192).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(192).axis = [-0 -1 -0];
smiData.RigidTransform(192).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:MPM3610 Step-Down Module_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(193).translation = [5.582500000000004 1.0499999999999954 -15.549999999999999];  % mm
smiData.RigidTransform(193).angle = 1.5707963267948954;  % rad
smiData.RigidTransform(193).axis = [0 1 0];
smiData.RigidTransform(193).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(194).translation = [-4.0599999999999943 0.85000000000000353 14.1];  % mm
smiData.RigidTransform(194).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(194).axis = [-0 -1 -0];
smiData.RigidTransform(194).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:PMEG6020AELR Diode_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(195).translation = [4.4399999999999995 1.2250000000000039 -5.8500000000000005];  % mm
smiData.RigidTransform(195).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(195).axis = [0 1 0];
smiData.RigidTransform(195).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:CL21A226MQCLQNC Capacitor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(196).translation = [0.60999999999999943 1.1999999999999926 -6.1000000000000005];  % mm
smiData.RigidTransform(196).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(196).axis = [0 1 0];
smiData.RigidTransform(196).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:BLM18PG471SN1D Ferrite Bead_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(197).translation = [0 2.2199999999999998 19.200000000000003];  % mm
smiData.RigidTransform(197).angle = 0;  % rad
smiData.RigidTransform(197).axis = [0 0 0];
smiData.RigidTransform(197).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:ZX62-AB-5PA Micro USB_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(198).translation = [4.6274999999999995 0.82000000000000128 12];  % mm
smiData.RigidTransform(198).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(198).axis = [0 1 0];
smiData.RigidTransform(198).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:LSM6DS3 Accelerometer_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(199).translation = [-4.110000000000003 1.2250000000000039 7.8375000000000004];  % mm
smiData.RigidTransform(199).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(199).axis = [-0 -1 -0];
smiData.RigidTransform(199).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:CL21A226MQCLQNC Capacitor_1.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(200).translation = [-3.6400000000000041 1.0500000000000091 10.73];  % mm
smiData.RigidTransform(200).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(200).axis = [-0 -1 -0];
smiData.RigidTransform(200).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-16]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(201).translation = [-2.0100000000000118 1.0000000000000009 8.1624999999999996];  % mm
smiData.RigidTransform(201).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(201).axis = [0 1 0];
smiData.RigidTransform(201).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07100KL Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(202).translation = [-1.6975000000000047 1.0000000000000009 6.7124999999999995];  % mm
smiData.RigidTransform(202).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(202).axis = [-0 -1 -0];
smiData.RigidTransform(202).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07100KL Resistor_1.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(203).translation = [-5.8099999999999961 1.0000000000000009 16.600000000000005];  % mm
smiData.RigidTransform(203).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(203).axis = [-0 -1 -0];
smiData.RigidTransform(203).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07330RL Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(204).translation = [5.0899999999999972 1.0499999999999954 3.1000000000000001];  % mm
smiData.RigidTransform(204).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(204).axis = [0 1 0];
smiData.RigidTransform(204).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-18]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(205).translation = [5.802500000000002 1.0000000000000009 17.200000000000003];  % mm
smiData.RigidTransform(205).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(205).axis = [-0 -1 -0];
smiData.RigidTransform(205).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07330RL Resistor_1.stp-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(206).translation = [-5.5899999999999981 1.2000000000000066 4.4000000000000004];  % mm
smiData.RigidTransform(206).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(206).axis = [-0 -1 -0];
smiData.RigidTransform(206).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:GRM188R61E475KE11D Capacitor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(207).translation = [5.0899999999999972 1.0000000000000009 2.1000000000000001];  % mm
smiData.RigidTransform(207).angle = 0;  % rad
smiData.RigidTransform(207).axis = [0 0 0];
smiData.RigidTransform(207).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-074K7L Resistor_1.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(208).translation = [5.0899999999999972 1.0000000000000009 1.1000000000000001];  % mm
smiData.RigidTransform(208).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(208).axis = [0 1 5.0000000000000004e-16];
smiData.RigidTransform(208).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-074K7L Resistor_1.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(209).translation = [3.9149999999999947 1.0000000000000009 15.2325];  % mm
smiData.RigidTransform(209).angle = 1.5707963267948977;  % rad
smiData.RigidTransform(209).axis = [-0 -1 -0];
smiData.RigidTransform(209).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:RC0402FR-07330RL Resistor_1.stp-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(210).translation = [5.0899999999999972 1.0499999999999954 0.10000000000000001];  % mm
smiData.RigidTransform(210).angle = 0;  % rad
smiData.RigidTransform(210).axis = [0 0 0];
smiData.RigidTransform(210).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:GRM155R61E105KA12D Capacitor.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(211).translation = [5.0899999999999972 1.0499999999999954 -0.90000000000000002];  % mm
smiData.RigidTransform(211).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(211).axis = [0 1 0];
smiData.RigidTransform(211).ID = "AssemblyGround[Arduino Nano 33 IoT.stp-1:TDK C1005 Capacitor_1.stp-19]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(212).translation = [28.611947138241437 2.5000000000000022 12.329201137684855];  % mm
smiData.RigidTransform(212).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(212).axis = [0 0.70710678118654746 0.70710678118654757];
smiData.RigidTransform(212).ID = "AssemblyGround[Wheel Asssembly-3:pololu-universal-aluminum-mounting-hub-for-6mm-shaft-m3-holes.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(213).translation = [28.611898726034479 -2.600000000000005 12.329117285282729];  % mm
smiData.RigidTransform(213).angle = 1.82347658193698;  % rad
smiData.RigidTransform(213).axis = [-0.44721359549996154 -0.44721359549996104 0.77459666924147963];
smiData.RigidTransform(213).ID = "AssemblyGround[Wheel Asssembly-3:pololu-wheel-80x10mm-yellow.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(214).translation = [0 0 0];  % mm
smiData.RigidTransform(214).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(214).axis = [0 1 -5.5511151231257839e-17];
smiData.RigidTransform(214).ID = "AssemblyGround[Motor 37D-3:L-Bracket-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(215).translation = [2.5000000000000022 6.9999999997442597 7.073161500947832e-11];  % mm
smiData.RigidTransform(215).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(215).axis = [0 1 0];
smiData.RigidTransform(215).ID = "AssemblyGround[Motor 37D-3:Motor Shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(216).translation = [-56.499999999999993 -2.5585436547181928e-10 1.4787476798616694e-10];  % mm
smiData.RigidTransform(216).angle = 2.094395102389996;  % rad
smiData.RigidTransform(216).axis = [-0.57735026918855925 -0.5773502691917588 0.57735026918855925];
smiData.RigidTransform(216).ID = "AssemblyGround[Motor 37D-3:Motor Cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(217).translation = [-28.499999999999972 -2.5593416275171421e-10 1.4780971585581781e-10];  % mm
smiData.RigidTransform(217).angle = 2.0943951023868412;  % rad
smiData.RigidTransform(217).axis = [0.57735026918750698 0.57735026919386345 0.57735026918750698];
smiData.RigidTransform(217).ID = "AssemblyGround[Motor 37D-3:Motor Body-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(218).translation = [0 0 -0.29999999999999472];  % mm
smiData.RigidTransform(218).angle = 0;  % rad
smiData.RigidTransform(218).axis = [0 0 0];
smiData.RigidTransform(218).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(219).translation = [-4.5999999999999996 0 -9.5500000000000025];  % mm
smiData.RigidTransform(219).angle = 0;  % rad
smiData.RigidTransform(219).axis = [0 0 0];
smiData.RigidTransform(219).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Array.step-1:Body006.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(220).translation = [0 0 -9.5500000000000025];  % mm
smiData.RigidTransform(220).angle = 0;  % rad
smiData.RigidTransform(220).axis = [0 0 0];
smiData.RigidTransform(220).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Array.step-1:Body006.step-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(221).translation = [4.5999999999999996 0 -9.5500000000000025];  % mm
smiData.RigidTransform(221).angle = 0;  % rad
smiData.RigidTransform(221).axis = [0 0 0];
smiData.RigidTransform(221).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Array.step-1:Body006.step-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(222).translation = [0 0 0];  % mm
smiData.RigidTransform(222).angle = 0;  % rad
smiData.RigidTransform(222).axis = [0 0 0];
smiData.RigidTransform(222).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Array.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(223).translation = [0 0 6.0000000000000053];  % mm
smiData.RigidTransform(223).angle = 0.1745329251995372;  % rad
smiData.RigidTransform(223).axis = [0 1 0];
smiData.RigidTransform(223).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body002.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(224).translation = [0 0 0];  % mm
smiData.RigidTransform(224).angle = 0;  % rad
smiData.RigidTransform(224).axis = [0 0 0];
smiData.RigidTransform(224).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body001.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(225).translation = [0 0 5.3499999999999934];  % mm
smiData.RigidTransform(225).angle = 0;  % rad
smiData.RigidTransform(225).axis = [0 0 0];
smiData.RigidTransform(225).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body004.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(226).translation = [0 0 0.87500000000000078];  % mm
smiData.RigidTransform(226).angle = 0;  % rad
smiData.RigidTransform(226).axis = [0 0 0];
smiData.RigidTransform(226).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body003.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(227).translation = [0 0 1.7500000000000016];  % mm
smiData.RigidTransform(227).angle = 0;  % rad
smiData.RigidTransform(227).axis = [0 0 0];
smiData.RigidTransform(227).ID = "AssemblyGround[6mm SPDT Mini Toggle Switch.step-1:Body005.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(228).translation = [60.534449530031992 52.890027109654994 17.763070100704994];  % mm
smiData.RigidTransform(228).angle = 0;  % rad
smiData.RigidTransform(228).axis = [0 0 0];
smiData.RigidTransform(228).ID = "AssemblyGround[assembly of drv 8833.stp-1:Main chip.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(229).translation = [55.708449530031992 64.269227109654992 19.050470100704999];  % mm
smiData.RigidTransform(229).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(229).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(229).ID = "AssemblyGround[assembly of drv 8833.stp-1:main pcb ipt.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(230).translation = [63.398435728422008 47.083332167075994 18.263070100704994];  % mm
smiData.RigidTransform(230).angle = 1.5707963267948855;  % rad
smiData.RigidTransform(230).axis = [-1 4.9999999999999787e-16 5.8500000000000003e-14];
smiData.RigidTransform(230).ID = "AssemblyGround[assembly of drv 8833.stp-1:transsitor.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(231).translation = [59.384932272169998 54.635971252656987 18.406768298263003];  % mm
smiData.RigidTransform(231).angle = 3.1415926535897598;  % rad
smiData.RigidTransform(231).axis = [0.70710678118654746 -0.70710678118654757 -2.4395183950935892e-14];
smiData.RigidTransform(231).ID = "AssemblyGround[assembly of drv 8833.stp-1:Resistor.stp-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(232).translation = [63.375201305088005 51.279227687037995 18.263070100705008];  % mm
smiData.RigidTransform(232).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(232).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(232).ID = "AssemblyGround[assembly of drv 8833.stp-1:black.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(233).translation = [59.186834008405 49.709095644095996 18.263070100704994];  % mm
smiData.RigidTransform(233).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(233).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(233).ID = "AssemblyGround[assembly of drv 8833.stp-1:Resistor.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(234).translation = [59.481543419354999 58.968460003378993 18.263070100704994];  % mm
smiData.RigidTransform(234).angle = 3.1415926535897598;  % rad
smiData.RigidTransform(234).axis = [0.70710678118654746 -0.70710678118654757 -2.5102290732122441e-14];
smiData.RigidTransform(234).ID = "AssemblyGround[assembly of drv 8833.stp-1:Resistor.stp-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(235).translation = [58.812974610725 46.292801593020002 18.263070100705008];  % mm
smiData.RigidTransform(235).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(235).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(235).ID = "AssemblyGround[assembly of drv 8833.stp-1:sdasdsa.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(236).translation = [59.641493935602 48.221981916730996 18.263070100705008];  % mm
smiData.RigidTransform(236).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(236).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(236).ID = "AssemblyGround[assembly of drv 8833.stp-1:1231.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(237).translation = [59.705032480170999 62.278298635127996 18.263070100705008];  % mm
smiData.RigidTransform(237).angle = 3.1415926535897598;  % rad
smiData.RigidTransform(237).axis = [0.70710678118654746 -0.70710678118654757 -2.5102290732122441e-14];
smiData.RigidTransform(237).ID = "AssemblyGround[assembly of drv 8833.stp-1:black.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(238).translation = [62.049330430952999 46.252483798235993 18.263070100704006];  % mm
smiData.RigidTransform(238).angle = 3.1415926535897811;  % rad
smiData.RigidTransform(238).axis = [-1 -8.8499999999999825e-14 2.949999999999947e-14];
smiData.RigidTransform(238).ID = "AssemblyGround[assembly of drv 8833.stp-1:Resistor - Capacitro.stp-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(239).translation = [28.611947138241437 2.5000000000000022 12.329201137684855];  % mm
smiData.RigidTransform(239).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(239).axis = [0 0.70710678118654746 0.70710678118654757];
smiData.RigidTransform(239).ID = "AssemblyGround[Wheel Asssembly-1:pololu-universal-aluminum-mounting-hub-for-6mm-shaft-m3-holes.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(240).translation = [28.611898726034486 -2.600000000000005 12.329117285282726];  % mm
smiData.RigidTransform(240).angle = 1.82347658193698;  % rad
smiData.RigidTransform(240).axis = [-0.44721359549996154 -0.44721359549996104 0.77459666924147963];
smiData.RigidTransform(240).ID = "AssemblyGround[Wheel Asssembly-1:pololu-wheel-80x10mm-yellow.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(241).translation = [0 0 0];  % mm
smiData.RigidTransform(241).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(241).axis = [0 1 -5.5511151231257839e-17];
smiData.RigidTransform(241).ID = "AssemblyGround[Motor 37D-1:L-Bracket-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(242).translation = [2.5000000000000022 6.9999999997442597 7.0731615009478345e-11];  % mm
smiData.RigidTransform(242).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(242).axis = [0 1 0];
smiData.RigidTransform(242).ID = "AssemblyGround[Motor 37D-1:Motor Shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(243).translation = [-56.499999999999993 -2.5585436547181928e-10 1.4787476798616694e-10];  % mm
smiData.RigidTransform(243).angle = 2.094395102389996;  % rad
smiData.RigidTransform(243).axis = [-0.57735026918855925 -0.5773502691917588 0.57735026918855925];
smiData.RigidTransform(243).ID = "AssemblyGround[Motor 37D-1:Motor Cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(244).translation = [-28.499999999999972 -2.5593416275171421e-10 1.4780971585581781e-10];  % mm
smiData.RigidTransform(244).angle = 2.0943951023868412;  % rad
smiData.RigidTransform(244).axis = [0.57735026918750698 0.57735026919386345 0.57735026918750698];
smiData.RigidTransform(244).ID = "AssemblyGround[Motor 37D-1:Motor Body-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(245).translation = [0 0 0];  % mm
smiData.RigidTransform(245).angle = 0;  % rad
smiData.RigidTransform(245).axis = [0 0 0];
smiData.RigidTransform(245).ID = "RootGround[Acrylic Frame-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(246).translation = [0 0 0];  % mm
smiData.RigidTransform(246).angle = 0;  % rad
smiData.RigidTransform(246).axis = [0 0 0];
smiData.RigidTransform(246).ID = "RootGround[Part1^ELEC391 Inv-Pendulum Assy V2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(247).translation = [-115 26.767649864853162 -11.858205795216184];  % mm
smiData.RigidTransform(247).angle = 1.7790272547732928;  % rad
smiData.RigidTransform(247).axis = [0.41390068662094648 0.41390068662094648 -0.81078507832188051];
smiData.RigidTransform(247).ID = "SixDofRigidTransform[Wheel Asssembly-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(248).translation = [-100 0 -20.800000000000612];  % mm
smiData.RigidTransform(248).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(248).axis = [-5.8878467200641535e-17 -0.70710678118654757 0.70710678118654746];
smiData.RigidTransform(248).ID = "SixDofRigidTransform[Motor 37D-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(249).translation = [92.000000000000028 -29.499999999999989 28.850000000000009];  % mm
smiData.RigidTransform(249).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(249).axis = [0.44162030411237713 0.89720204357529831 0];
smiData.RigidTransform(249).ID = "SixDofRigidTransform[PLA Thread Rod Spacer - 45mm-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(250).translation = [-92.000000000000028 29.499999999999989 28.850000000000009];  % mm
smiData.RigidTransform(250).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(250).axis = [0.89720204357529831 -0.44162030411237713 0];
smiData.RigidTransform(250).ID = "SixDofRigidTransform[PLA Thread Rod Spacer - 45mm-6]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(251).translation = [-92 -29.499999999999982 110.19999999999997];  % mm
smiData.RigidTransform(251).angle = 0.92612093410322183;  % rad
smiData.RigidTransform(251).axis = [0 0 1];
smiData.RigidTransform(251).ID = "SixDofRigidTransform[PLA Thread Rod Spacer - 45mm-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(252).translation = [-92 29.499999999999986 80.199999999999974];  % mm
smiData.RigidTransform(252).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(252).axis = [0.8946896146765243 -0.44668836272055767 0];
smiData.RigidTransform(252).ID = "SixDofRigidTransform[PLA Thread Rod Spacer - 45mm-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(253).translation = [-92.000000000000028 -29.499999999999986 28.849999999999994];  % mm
smiData.RigidTransform(253).angle = 0.91480764946120852;  % rad
smiData.RigidTransform(253).axis = [0 0 1];
smiData.RigidTransform(253).ID = "SixDofRigidTransform[PLA Thread Rod Spacer - 45mm-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(254).translation = [72.499999999999986 30.000000000000011 -3.0999999999999988];  % mm
smiData.RigidTransform(254).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(254).axis = [-0 -1 -0];
smiData.RigidTransform(254).ID = "SixDofRigidTransform[pan cross head_am-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(255).translation = [0 10.000000000000009 3.1749999999999976];  % mm
smiData.RigidTransform(255).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(255).axis = [-5.5511151231257852e-17 1 6.5824163566776225e-17];
smiData.RigidTransform(255).ID = "SixDofRigidTransform[TPU Frame Bumper - 50mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(256).translation = [-72.499999999999972 -30 -3.0999999999999988];  % mm
smiData.RigidTransform(256).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(256).axis = [-0 -1 -0];
smiData.RigidTransform(256).ID = "SixDofRigidTransform[pan cross head_am-11]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(257).translation = [-72.500000000000014 30 -3.1000000000000005];  % mm
smiData.RigidTransform(257).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(257).axis = [-0 -1 -0];
smiData.RigidTransform(257).ID = "SixDofRigidTransform[pan cross head_am-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(258).translation = [72.5 -29.999999999999986 -3.0999999999999988];  % mm
smiData.RigidTransform(258).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(258).axis = [-0 -1 -0];
smiData.RigidTransform(258).ID = "SixDofRigidTransform[pan cross head_am-9]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(66).mass = 0.0;
smiData.Solid(66).CoM = [0.0 0.0 0.0];
smiData.Solid(66).MoI = [0.0 0.0 0.0];
smiData.Solid(66).PoI = [0.0 0.0 0.0];
smiData.Solid(66).color = [0.0 0.0 0.0];
smiData.Solid(66).opacity = 0.0;
smiData.Solid(66).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.070658163384034939;  % kg
smiData.Solid(1).CoM = [82.326499018559204 3.8241158841003551 27.000000054280125];  % mm
smiData.Solid(1).MoI = [17.935079181254132 178.00997561807503 160.80901100148836];  % kg*mm^2
smiData.Solid(1).PoI = [-1.2947643682925972e-08 2.491986433270214e-07 -0.013184972428210708];  % kg*mm^2
smiData.Solid(1).color = [0.69999999999999996 0.69999999999999996 0.69999999999999996];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "6x2inBreadboard*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0;  % kg
smiData.Solid(2).CoM = [0 0 0];  % mm
smiData.Solid(2).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "RC0402FR-07100KL Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0;  % kg
smiData.Solid(3).CoM = [0 0 0];  % mm
smiData.Solid(3).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "RC0402FR-071KL Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0;  % kg
smiData.Solid(4).CoM = [0 0 0];  % mm
smiData.Solid(4).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "AC0402JR-0724KL Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0;  % kg
smiData.Solid(5).CoM = [0 0 0];  % mm
smiData.Solid(5).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "AC0402JR-0775KL Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 2.8088106461821663e-06;  % kg
smiData.Solid(6).CoM = [-7.1047040322274013e-11 -0.41235321663723096 -1.9214291922116503e-11];  % mm
smiData.Solid(6).MoI = [4.5990853460621626e-06 7.4568309832473071e-06 3.969407531795734e-06];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.95686274509803915 0.95686274509803915 0.95686274509803915];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "User Library-arduino_nano_reset shell_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 1.7112236323737246e-05;  % kg
smiData.Solid(7).CoM = [-1.1310299312915861e-05 0.81845320456788595 2.5918717149580347e-06];  % mm
smiData.Solid(7).MoI = [1.4101957807855087e-05 3.1068254670367505e-05 2.630880455379264e-05];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = "User Library-arduino_nano_reset core_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 7.0812816079483234e-07;  % kg
smiData.Solid(8).CoM = [-7.2092713504681716e-05 0.35000556897391766 3.3273560082545878e-05];  % mm
smiData.Solid(8).MoI = [7.4654253749605794e-08 1.276191037288408e-07 1.2740837380758938e-07];  % kg*mm^2
smiData.Solid(8).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = "HSMG-C190 LED_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 3.1182865952682811e-05;  % kg
smiData.Solid(9).CoM = [0 -0.16583501549743249 0];  % mm
smiData.Solid(9).MoI = [0.00031142845469698789 0.00057703003156679244 0.00027801530439232054];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(9).color = [0.74509803921568629 0.71764705882352942 0.66274509803921566];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = "NINA-W102 Cover.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.00011304554632201962;  % kg
smiData.Solid(10).CoM = [0.01028843517910368 0.39380238741998375 -1.3003608017643675e-05];  % mm
smiData.Solid(10).MoI = [0.00095220207734425868 0.0027680962141539518 0.0018283640116676879];  % kg*mm^2
smiData.Solid(10).PoI = [-6.1563950960365501e-10 -2.0780240411294792e-09 -1.294163456291777e-06];  % kg*mm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = "NINA-W102 Body_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 1.1121031642061064e-05;  % kg
smiData.Solid(11).CoM = [-1.7389070071807247 2.33511962618452 -0.24602841230589795];  % mm
smiData.Solid(11).MoI = [0.00013095939540874022 0.00014233342072284051 2.757502728181911e-05];  % kg*mm^2
smiData.Solid(11).PoI = [-6.3424453581538585e-06 2.8716566857983504e-06 1.7603625949242565e-06];  % kg*mm^2
smiData.Solid(11).color = [0.74509803921568629 0.73725490196078436 0.72941176470588232];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = "NINA-W102 Antenna_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 4.9526298041928404e-05;  % kg
smiData.Solid(12).CoM = [-0.001334154469918898 0.48934942012635507 -0.0020180175287604282];  % mm
smiData.Solid(12).MoI = [0.00020669125381159143 0.00040513867496995594 0.00020687398756826184];  % kg*mm^2
smiData.Solid(12).PoI = [4.6320058258110479e-08 -8.1213101097258834e-08 2.9874936674836907e-08];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = "atmegaSAMD21_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 3.2740868194955265e-07;  % kg
smiData.Solid(13).CoM = [0 -0.030807532297872229 0];  % mm
smiData.Solid(13).MoI = [1.261551840475863e-08 6.8376761066971015e-08 6.8210118773009022e-08];  % kg*mm^2
smiData.Solid(13).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(13).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = "TDK C1005 Capacitor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(14).mass = 0.0012002189872195343;  % kg
smiData.Solid(14).CoM = [0.00031018114096672102 -0.00098652288998762644 -0.028900851604640235];  % mm
smiData.Solid(14).MoI = [0.19231909579171352 0.22173393506650291 0.029933687744738847];  % kg*mm^2
smiData.Solid(14).PoI = [-9.5870365482187089e-06 2.4657740234921717e-05 4.8674990257021951e-07];  % kg*mm^2
smiData.Solid(14).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(14).opacity = 1;
smiData.Solid(14).ID = "Nano_33IoT Body_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(15).mass = 3.5315500286582541e-06;  % kg
smiData.Solid(15).CoM = [-0.0079759397663403484 -0.033458658586485564 0.013855358576504535];  % mm
smiData.Solid(15).MoI = [9.0473455430970826e-07 3.2213034114478299e-06 2.8139890818304652e-06];  % kg*mm^2
smiData.Solid(15).PoI = [1.5922340559834228e-08 2.6568786196778108e-08 -8.6898305332452848e-09];  % kg*mm^2
smiData.Solid(15).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(15).opacity = 1;
smiData.Solid(15).ID = "PRTR5V0U2X Protection Diode_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(16).mass = 3.7966181042492066e-06;  % kg
smiData.Solid(16).CoM = [3.3327476410838931e-10 -0.068632982342157089 -4.7720063828251878e-09];  % mm
smiData.Solid(16).MoI = [9.8440184936030271e-07 2.6908557696537937e-06 2.7039610572167087e-06];  % kg*mm^2
smiData.Solid(16).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(16).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(16).opacity = 1;
smiData.Solid(16).ID = "C0805C472KDRACTU Capacitor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(17).mass = 3.2677486269133879e-06;  % kg
smiData.Solid(17).CoM = [3.5252276191824946e-06 0.257638994727589 0.00019970984402222527];  % mm
smiData.Solid(17).MoI = [2.5935371911270462e-06 3.5982998644650908e-06 1.1640692902894316e-06];  % kg*mm^2
smiData.Solid(17).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(17).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(17).opacity = 1;
smiData.Solid(17).ID = "ATECC608A No Lead Crypto Auth_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(18).mass = 2.4283529875334779e-05;  % kg
smiData.Solid(18).CoM = [-0.00030069473255525951 -0.010444132631737308 -0.00022167768572091808];  % mm
smiData.Solid(18).MoI = [5.6143667912569972e-05 6.9271350380397894e-05 2.3749267179515724e-05];  % kg*mm^2
smiData.Solid(18).PoI = [2.3326269165172748e-08 1.5660223409727076e-08 7.7655704300509805e-09];  % kg*mm^2
smiData.Solid(18).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(18).opacity = 1;
smiData.Solid(18).ID = "MPM3610 Step-Down Module_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(19).mass = 4.8516879524871007e-06;  % kg
smiData.Solid(19).CoM = [-0.0021257651485810658 0.5002363380594137 -1.8176175709441087e-05];  % mm
smiData.Solid(19).MoI = [1.7425761541990245e-06 4.0210234745335227e-06 3.1926108247610862e-06];  % kg*mm^2
smiData.Solid(19).PoI = [0 0 5.7084192294841062e-09];  % kg*mm^2
smiData.Solid(19).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(19).opacity = 1;
smiData.Solid(19).ID = "PMEG6020AELR Diode_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(20).mass = 2.4329678266360025e-06;  % kg
smiData.Solid(20).CoM = [1.3173757146004781e-09 -0.035406953626696332 -5.9198913907961263e-09];  % mm
smiData.Solid(20).MoI = [4.5670317730215835e-07 1.5189735055402221e-06 1.3540557415197466e-06];  % kg*mm^2
smiData.Solid(20).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(20).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(20).opacity = 1;
smiData.Solid(20).ID = "CL21A226MQCLQNC Capacitor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(21).mass = 1.1799287442429905e-06;  % kg
smiData.Solid(21).CoM = [0 -0.037560542927453852 0];  % mm
smiData.Solid(21).MoI = [1.2386460284227986e-07 4.541258981189364e-07 4.5581589361776351e-07];  % kg*mm^2
smiData.Solid(21).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(21).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(21).opacity = 1;
smiData.Solid(21).ID = "BLM18PG471SN1D Ferrite Bead_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(22).mass = 6.0807577018272863e-09;  % kg
smiData.Solid(22).CoM = [-4.557109152646963e-06 0.37513776198943816 2.4041142916436868];  % mm
smiData.Solid(22).MoI = [0 5.2682043179762305e-09 5.294385720085994e-09];  % kg*mm^2
smiData.Solid(22).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(22).color = [0.74509803921568629 0.73725490196078436 0.72941176470588232];
smiData.Solid(22).opacity = 1;
smiData.Solid(22).ID = "ZX62-AB-5PA Micro USB_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(23).mass = 6.270672344134893e-06;  % kg
smiData.Solid(23).CoM = [0.00077044886589562416 0.41088223179563743 -0.0010415648262963337];  % mm
smiData.Solid(23).MoI = [5.0714065691192502e-06 7.9715277788709629e-06 3.6315395104827815e-06];  % kg*mm^2
smiData.Solid(23).PoI = [2.272901872909895e-09 -5.091258982761976e-09 -1.6197680641860671e-09];  % kg*mm^2
smiData.Solid(23).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(23).opacity = 1;
smiData.Solid(23).ID = "LSM6DS3 Accelerometer_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(24).mass = 0;  % kg
smiData.Solid(24).CoM = [0 0 0];  % mm
smiData.Solid(24).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(24).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(24).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(24).opacity = 1;
smiData.Solid(24).ID = "RC0402FR-07330RL Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(25).mass = 1.1799287840525931e-06;  % kg
smiData.Solid(25).CoM = [-8.6872295312330235e-10 -0.03756053468370131 1.0685149042775073e-08];  % mm
smiData.Solid(25).MoI = [1.2386460930853619e-07 4.5412591983827968e-07 4.5581591339904883e-07];  % kg*mm^2
smiData.Solid(25).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(25).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(25).opacity = 1;
smiData.Solid(25).ID = "GRM188R61E475KE11D Capacitor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(26).mass = 0;  % kg
smiData.Solid(26).CoM = [0 0 0];  % mm
smiData.Solid(26).MoI = [0 0 0];  % kg*mm^2
smiData.Solid(26).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(26).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(26).opacity = 1;
smiData.Solid(26).ID = "RC0402FR-074K7L Resistor_1.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(27).mass = 3.2740868194950702e-07;  % kg
smiData.Solid(27).CoM = [0 -0.030807532297880191 0];  % mm
smiData.Solid(27).MoI = [1.2615518404756974e-08 6.8376761066958018e-08 6.821011877299674e-08];  % kg*mm^2
smiData.Solid(27).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(27).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(27).opacity = 1;
smiData.Solid(27).ID = "GRM155R61E105KA12D Capacitor.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(28).mass = 0.0025222374048805883;  % kg
smiData.Solid(28).CoM = [-0.091846717730238614 -0.15631738893867128 0.62020387563937596];  % mm
smiData.Solid(28).MoI = [0.10691480824434131 0.10878508812389695 0.19306396645122481];  % kg*mm^2
smiData.Solid(28).PoI = [3.5730762762602407e-05 2.8483919934921017e-05 0.0016561993073387195];  % kg*mm^2
smiData.Solid(28).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(28).opacity = 1;
smiData.Solid(28).ID = "pololu-universal-aluminum-mounting-hub-for-6mm-shaft-m3-holes.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(29).mass = 0.019220063421573483;  % kg
smiData.Solid(29).CoM = [-0.028404396690012722 0.00080002831101479101 2.7899909646128687e-05];  % mm
smiData.Solid(29).MoI = [21.836211124498327 11.052660481109903 11.048914496700638];  % kg*mm^2
smiData.Solid(29).PoI = [-2.97948123602336e-06 -1.5922087145745205e-06 1.3867795710295745e-05];  % kg*mm^2
smiData.Solid(29).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(29).opacity = 1;
smiData.Solid(29).ID = "pololu-wheel-80x10mm-yellow.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(30).mass = 0.0054707025930806714;  % kg
smiData.Solid(30).CoM = [17.726018933311781 -14.171715279596061 0];  % mm
smiData.Solid(30).MoI = [1.2294888235544299 2.1778729859511219 2.0858610535716697];  % kg*mm^2
smiData.Solid(30).PoI = [0 0 0.51501203462729472];  % kg*mm^2
smiData.Solid(30).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(30).opacity = 1;
smiData.Solid(30).ID = "L-Bracket*:*Predeterminado";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(31).mass = 0.00047671661121962468;  % kg
smiData.Solid(31).CoM = [0 -0.099962248062764714 8.6456788245643885];  % mm
smiData.Solid(31).MoI = [0.013251258731236941 0.013368946299837739 0.0020826670311053005];  % kg*mm^2
smiData.Solid(31).PoI = [0.00013601886266009997 0 0];  % kg*mm^2
smiData.Solid(31).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(31).opacity = 1;
smiData.Solid(31).ID = "Motor Shaft*:*Predeterminado";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(32).mass = 0.00079485623707183496;  % kg
smiData.Solid(32).CoM = [-0.0054061360799674534 0.0054059965288335123 0.59666068483082157];  % mm
smiData.Solid(32).MoI = [0.04751661117089398 0.044776641495585266 0.09184097001529809];  % kg*mm^2
smiData.Solid(32).PoI = [-4.8791498922395169e-06 4.8791915653962009e-06 6.21335034244194e-07];  % kg*mm^2
smiData.Solid(32).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(32).opacity = 1;
smiData.Solid(32).ID = "Motor Cover*:*Predeterminado";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(33).mass = 0.052794533438481929;  % kg
smiData.Solid(33).CoM = [0.089834524232888971 4.8007334858530084e-08 0.89626501911943945];  % mm
smiData.Solid(33).MoI = [17.469513881589229 17.502532954137251 8.0762528341644817];  % kg*mm^2
smiData.Solid(33).PoI = [-6.4877335943633763e-08 -0.13587684487977209 6.1087310353164105e-06];  % kg*mm^2
smiData.Solid(33).color = [0.6470588235294118 0.61960784313725492 0.58431372549019611];
smiData.Solid(33).opacity = 1;
smiData.Solid(33).ID = "Motor Body*:*Predeterminado";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(34).mass = 0.0460797099603035;  % kg
smiData.Solid(34).CoM = [-0.00053484850865730788 52.960455690638064 -0.0068102804092857365];  % mm
smiData.Solid(34).MoI = [15.002550084208917 26.600649306770645 40.433688685129923];  % kg*mm^2
smiData.Solid(34).PoI = [-0.0040019693580827026 -0.00014351520505470736 -0.00034272204109789321];  % kg*mm^2
smiData.Solid(34).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(34).opacity = 1;
smiData.Solid(34).ID = "TPU Frame Bumper - 50mm*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(35).mass = 0.0033791330781300978;  % kg
smiData.Solid(35).CoM = [-1.6569188987607582 0.004899814144065491 -15.025476337477579];  % mm
smiData.Solid(35).MoI = [1.9383560569819092 1.9169695738734851 0.065611899591937126];  % kg*mm^2
smiData.Solid(35).PoI = [-4.2510723733009115e-05 -0.00036053842812080973 6.354947420718323e-05];  % kg*mm^2
smiData.Solid(35).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(35).opacity = 1;
smiData.Solid(35).ID = "PLA Thread Rod Spacer - 45mm*:*Assignment";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(36).mass = 0.0021564928446415692;  % kg
smiData.Solid(36).CoM = [-1.5306010786526592 -0.0026555967512764292 0.0005172766328400126];  % mm
smiData.Solid(36).MoI = [0.49883769557288865 0.48340377601359363 0.045194701888025504];  % kg*mm^2
smiData.Solid(36).PoI = [1.0536221153237267e-05 8.7557301019773749e-06 -1.68580947904474e-05];  % kg*mm^2
smiData.Solid(36).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(36).opacity = 1;
smiData.Solid(36).ID = "PLA Thread Rod Spacer - 45mm*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(37).mass = 0.024520588357479143;  % kg
smiData.Solid(37).CoM = [0.11438589789941241 0.97693173168341996 -0.0090188187433111553];  % mm
smiData.Solid(37).MoI = [15.120204344573722 14.560902074332018 1.9111057840851942];  % kg*mm^2
smiData.Solid(37).PoI = [-0.00077248764769820939 -6.8141899040456865e-05 0.025426355811257201];  % kg*mm^2
smiData.Solid(37).color = [0.48588235294117643 0.068627450980392149 0.068627450980392149];
smiData.Solid(37).opacity = 1;
smiData.Solid(37).ID = "PLA Battery Holder - 8xAA Horizontal Position*:*Pusher";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(38).mass = 0.093726304289383278;  % kg
smiData.Solid(38).CoM = [0.0054438013808408492 -0.0062153449437115631 3.1708567190940067];  % mm
smiData.Solid(38).MoI = [43.580234433046193 305.35292169590844 348.3048203550855];  % kg*mm^2
smiData.Solid(38).PoI = [0.0017950314269195012 -0.0015779895773813605 -0.020273995178442354];  % kg*mm^2
smiData.Solid(38).color = [1 1 1];
smiData.Solid(38).opacity = 1;
smiData.Solid(38).ID = "Custom Frame - LvL 3 ELEC 391 Project requirement*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(39).mass = 0.00055525173303253169;  % kg
smiData.Solid(39).CoM = [16.714384364147246 0 0];  % mm
smiData.Solid(39).MoI = [0.0017589782354167098 0.077781651801647533 0.077781651801647533];  % kg*mm^2
smiData.Solid(39).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(39).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(39).opacity = 1;
smiData.Solid(39).ID = "pan cross head_am*:*B18.6.7M - M4 x 0.7 x 35 Type I Cross Recessed PHMS --35N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(40).mass = 0.00013803359471627113;  % kg
smiData.Solid(40).CoM = [6.4056040925546096 0 0];  % mm
smiData.Solid(40).MoI = [0.00027931427810942109 0.0031595462490634119 0.0031595462490634119];  % kg*mm^2
smiData.Solid(40).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(40).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(40).opacity = 1;
smiData.Solid(40).ID = "pan cross head_am*:*B18.6.7M - M3 x 0.5 x 13 Type I Cross Recessed PHMS --13N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(41).mass = 0.094121881014172973;  % kg
smiData.Solid(41).CoM = [0 0 3.1749999999999994];  % mm
smiData.Solid(41).MoI = [43.838926477883845 307.85290209592671 351.05929031594491];  % kg*mm^2
smiData.Solid(41).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(41).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(41).opacity = 1;
smiData.Solid(41).ID = "Acrylic Frame*:*Simple";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(42).mass = 0.0007228327889641983;  % kg
smiData.Solid(42).CoM = [0 -1.0401957812312927e-07 -4.6442651133816018];  % mm
smiData.Solid(42).MoI = [0.0074070503661540343 0.015533816896846697 0.01249561269173234];  % kg*mm^2
smiData.Solid(42).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(42).color = [0.79607843137254897 0 0];
smiData.Solid(42).opacity = 1;
smiData.Solid(42).ID = "Body.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(43).mass = 4.359551467747277e-06;  % kg
smiData.Solid(43).CoM = [0 0 -1.8695147870174769];  % mm
smiData.Solid(43).MoI = [7.9710230015007289e-06 6.4553392315469296e-06 1.8226688524743368e-06];  % kg*mm^2
smiData.Solid(43).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(43).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(43).opacity = 1;
smiData.Solid(43).ID = "Body006.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(44).mass = 9.8120749056567711e-05;  % kg
smiData.Solid(44).CoM = [0 0 5.1025789567379851];  % mm
smiData.Solid(44).MoI = [0.0020580506093735356 0.0020580506093735348 0.00011426734052575977];  % kg*mm^2
smiData.Solid(44).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(44).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(44).opacity = 1;
smiData.Solid(44).ID = "Body002.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(45).mass = 0.00024679141805641658;  % kg
smiData.Solid(45).CoM = [-0.033248218019320243 0 1.6947400338253242];  % mm
smiData.Solid(45).MoI = [0.0051462601891575444 0.005282867028942994 0.0021172689354548259];  % kg*mm^2
smiData.Solid(45).PoI = [0 2.1851067424997912e-05 0];  % kg*mm^2
smiData.Solid(45).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(45).opacity = 1;
smiData.Solid(45).ID = "Body001.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(46).mass = 4.4319653794006875e-05;  % kg
smiData.Solid(46).CoM = [6.9411722917747241e-13 -7.8188909613187687e-13 0.87499999999977618];  % mm
smiData.Solid(46).MoI = [0.00029359644243534842 0.00029359661761736434 0.00056587813559879198];  % kg*mm^2
smiData.Solid(46).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(46).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(46).opacity = 1;
smiData.Solid(46).ID = "Body004.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(47).mass = 4.4319653794006957e-05;  % kg
smiData.Solid(47).CoM = [6.8920062229925327e-13 -7.8559591698028148e-13 0];  % mm
smiData.Solid(47).MoI = [0.00029359644243534902 0.00029359661761736478 0.00056587813559879274];  % kg*mm^2
smiData.Solid(47).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(47).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(47).opacity = 1;
smiData.Solid(47).ID = "Body003.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(48).mass = 5.3070931931673743e-05;  % kg
smiData.Solid(48).CoM = [0.29163613714740677 0 0.32450868366190361];  % mm
smiData.Solid(48).MoI = [0.00056727802509614212 0.00066154566299347656 0.0012232278190398246];  % kg*mm^2
smiData.Solid(48).PoI = [0 -8.2796054050837067e-06 0];  % kg*mm^2
smiData.Solid(48).color = [0.82745098039215681 0.82745098039215681 0.82745098039215681];
smiData.Solid(48).opacity = 1;
smiData.Solid(48).ID = "Body005.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(49).mass = 8.6102698908993112e-06;  % kg
smiData.Solid(49).CoM = [2.0500000000000518 2.0500000000000025 0.25283554111672968];  % mm
smiData.Solid(49).MoI = [1.2562744070249668e-05 1.256280471002342e-05 2.4766817779271993e-05];  % kg*mm^2
smiData.Solid(49).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(49).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(49).opacity = 1;
smiData.Solid(49).ID = "Main chip.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(50).mass = 0.00019644386807513483;  % kg
smiData.Solid(50).CoM = [6.3499999999999961 10.159548875256593 0.39326703832584808];  % mm
smiData.Solid(50).MoI = [0.0067723424944915126 0.0025666461573421321 0.0093187330793239598];  % kg*mm^2
smiData.Solid(50).PoI = [3.4485231401613298e-08 0 0];  % kg*mm^2
smiData.Solid(50).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(50).opacity = 1;
smiData.Solid(50).ID = "main pcb ipt.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(51).mass = 3.4155657938810496e-06;  % kg
smiData.Solid(51).CoM = [0.60364169102272303 0.48732188274006227 1.400000000000025];  % mm
smiData.Solid(51).MoI = [2.3911484856076207e-06 2.6500095622991172e-06 8.0190313585228396e-07];  % kg*mm^2
smiData.Solid(51).PoI = [0 0 -1.3884972079738936e-08];  % kg*mm^2
smiData.Solid(51).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(51).opacity = 1;
smiData.Solid(51).ID = "transsitor.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(52).mass = 7.3455999999999839e-07;  % kg
smiData.Solid(52).CoM = [0.89999999999999925 0.39999999999994212 0.25227728163798679];  % mm
smiData.Solid(52).MoI = [5.5669321229942446e-08 2.1731800922994085e-07 2.4180837866666497e-07];  % kg*mm^2
smiData.Solid(52).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(52).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(52).opacity = 1;
smiData.Solid(52).ID = "Resistor.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(53).mass = 7.3455999999999776e-07;  % kg
smiData.Solid(53).CoM = [0.8999999999999988 0.39999999999994168 0.25227728163798691];  % mm
smiData.Solid(53).MoI = [5.5669321229942406e-08 2.1731800922994053e-07 2.4180837866666465e-07];  % kg*mm^2
smiData.Solid(53).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(53).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(53).opacity = 1;
smiData.Solid(53).ID = "black.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(54).mass = 7.1300000000000327e-07;  % kg
smiData.Solid(54).CoM = [0.90000000000000124 0.39999999999999919 0.24759467040673325];  % mm
smiData.Solid(54).MoI = [5.282980819308103e-08 2.0783230819308228e-07 2.3151083333333445e-07];  % kg*mm^2
smiData.Solid(54).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(54).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(54).opacity = 1;
smiData.Solid(54).ID = "sdasdsa.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(55).mass = 1.2144839618872538e-06;  % kg
smiData.Solid(55).CoM = [0.75000000000000056 0.55000000000000004 0.3417922380889904];  % mm
smiData.Solid(55).MoI = [1.6699428838890595e-07 3.2693262567135876e-07 3.9534183569442358e-07];  % kg*mm^2
smiData.Solid(55).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(55).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(55).opacity = 1;
smiData.Solid(55).ID = "1231.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(56).mass = 5.2922400000000053e-06;  % kg
smiData.Solid(56).CoM = [1.7500000000000016 0.75000000000000056 0.50174051063443814];  % mm
smiData.Solid(56).MoI = [1.4457033838084462e-06 5.8935875758084524e-06 6.45101940800001e-06];  % kg*mm^2
smiData.Solid(56).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(56).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(56).opacity = 1;
smiData.Solid(56).ID = "Resistor - Capacitro.stp*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(57).mass = 0.02929738956694479;  % kg
smiData.Solid(57).CoM = [-0.071810008732692748 0.82626091786110267 0.0014411042958386295];  % mm
smiData.Solid(57).MoI = [15.337364752748973 14.797851811168051 2.1516512268195629];  % kg*mm^2
smiData.Solid(57).PoI = [-0.00048729130584664699 -1.3480275224296263e-05 0.022607217427749453];  % kg*mm^2
smiData.Solid(57).color = [0.48588235294117643 0.068627450980392149 0.068627450980392149];
smiData.Solid(57).opacity = 1;
smiData.Solid(57).ID = "PLA Battery Holder - 8xAA Horizontal Position*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(58).mass = 0.1079199855799024;  % kg
smiData.Solid(58).CoM = [0 0 3.1749999999999998];  % mm
smiData.Solid(58).MoI = [76.703961379334601 309.7724359441105 385.75113005368752];  % kg*mm^2
smiData.Solid(58).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(58).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(58).opacity = 1;
smiData.Solid(58).ID = "Acrylic Frame*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(59).mass = 0.0063879468780772596;  % kg
smiData.Solid(59).CoM = [0.024988928266436717 4.3355026323194528 -0.053978751302846399];  % mm
smiData.Solid(59).MoI = [0.65493024872348971 0.22646416472815559 0.64589210198791425];  % kg*mm^2
smiData.Solid(59).PoI = [0.0010442285318722582 -1.5661966101164449e-05 0.000334714595390497];  % kg*mm^2
smiData.Solid(59).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(59).opacity = 1;
smiData.Solid(59).ID = "PLA Puser - 8xAA Battery Holder*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(60).mass = 0.17005670935572567;  % kg
smiData.Solid(60).CoM = [0.72565746558879485 0.65651599629724189 -0.0031744909080632937];  % mm
smiData.Solid(60).MoI = [84.051062016139298 234.49485035371168 308.56281357611482];  % kg*mm^2
smiData.Solid(60).PoI = [0.019611466851542164 0.025642183442011322 -8.9202078093011092];  % kg*mm^2
smiData.Solid(60).color = [0.10980392156862745 0.10980392156862745 0.10980392156862745];
smiData.Solid(60).opacity = 1;
smiData.Solid(60).ID = "AA Battery Mock*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(61).mass = 7.4416436066305082e-05;  % kg
smiData.Solid(61).CoM = [2.5634226129985236 0 0];  % mm
smiData.Solid(61).MoI = [0.00020774487846811281 0.00031074173498201721 0.00031074173498201715];  % kg*mm^2
smiData.Solid(61).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(61).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(61).opacity = 1;
smiData.Solid(61).ID = "pan cross head_am*:*B18.6.7M - M3 x 0.5 x 4 Type I Cross Recessed PHMS --4N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(62).mass = 0.0004875839816802469;  % kg
smiData.Solid(62).CoM = [0 -1.1513393396580134e-07 -0.11293918732251913];  % in
smiData.Solid(62).MoI = [9.7397508100304682e-06 9.7396992706456968e-06 1.545624086504976e-05];  % kg*in^2
smiData.Solid(62).PoI = [0 0 4.0198738048833238e-12];  % kg*in^2
smiData.Solid(62).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(62).opacity = 1;
smiData.Solid(62).ID = "hex nut_ai*:*HNUT 0.2500-20-D-N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(63).mass = 0.00010662444846940396;  % kg
smiData.Solid(63).CoM = [0 1.3702747500961233e-06 -1.5985959803450975];  % mm
smiData.Solid(63).MoI = [0.00052487586358693575 0.0005248729418057727 0.00087302244809775193];  % kg*mm^2
smiData.Solid(63).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(63).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(63).opacity = 1;
smiData.Solid(63).ID = "hex nut style 1_am*:*B18.2.4.1M - Hex nut, Style 1,  M4 x 0.7 --D-N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(64).mass = 5.0309757439819635e-05;  % kg
smiData.Solid(64).CoM = [0 1.088789787468207e-06 -1.1987979660068981];  % mm
smiData.Solid(64).MoI = [0.00014902625833658974 0.00014902539741460267 0.00025103786062952469];  % kg*mm^2
smiData.Solid(64).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(64).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(64).opacity = 1;
smiData.Solid(64).ID = "hex nut style 1_am*:*B18.2.4.1M - Hex nut, Style 1,  M3 x 0.5 --D-N";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(65).mass = 0.0056356303764676582;  % kg
smiData.Solid(65).CoM = [-0.00034917888164398461 -0.00089157282509133812 0.077832614912042089];  % mm
smiData.Solid(65).MoI = [24.587971641267082 24.587984590118509 0.022878994970261433];  % kg*mm^2
smiData.Solid(65).PoI = [0.00030081356779069465 -2.4559355596607718e-05 -1.8616703046637972e-06];  % kg*mm^2
smiData.Solid(65).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(65).opacity = 1;
smiData.Solid(65).ID = "250mm ROD*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(66).mass = 0;  % kg
smiData.Solid(66).CoM = [0 0 0];  % in
smiData.Solid(66).MoI = [0 0 0];  % kg*in^2
smiData.Solid(66).PoI = [0 0 0];  % kg*in^2
smiData.Solid(66).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(66).opacity = 1;
smiData.Solid(66).ID = "Part1^ELEC391 Inv-Pendulum Assy V2*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(11).Rz.Pos = 0.0;
smiData.CylindricalJoint(11).Pz.Pos = 0.0;
smiData.CylindricalJoint(11).ID = "";

smiData.CylindricalJoint(1).Rz.Pos = -99.197964016402565;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = "[PLA Battery Holder - 8xAA Horizontal Position-1:-:pan cross head_am-48]";

smiData.CylindricalJoint(2).Rz.Pos = -99.407813226111159;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = "[250mm ROD-1:-:hex nut_ai-2]";

smiData.CylindricalJoint(3).Rz.Pos = -99.407813226111159;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = "[Acrylic Frame-4:-:250mm ROD-1]";

smiData.CylindricalJoint(4).Rz.Pos = 5.616318494627766;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = "[250mm ROD-2:-:hex nut_ai-4]";

smiData.CylindricalJoint(5).Rz.Pos = 5.616318494627766;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(5).ID = "[Acrylic Frame-4:-:250mm ROD-2]";

smiData.CylindricalJoint(6).Rz.Pos = 94.674983174842836;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(6).ID = "[250mm ROD-3:-:hex nut_ai-3]";

smiData.CylindricalJoint(7).Rz.Pos = 94.674983174842836;  % deg
smiData.CylindricalJoint(7).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(7).ID = "[Acrylic Frame-4:-:250mm ROD-3]";

smiData.CylindricalJoint(8).Rz.Pos = 147.29942174191297;  % deg
smiData.CylindricalJoint(8).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(8).ID = "[Acrylic Frame-4:-:250mm ROD-4]";

smiData.CylindricalJoint(9).Rz.Pos = 0;  % deg
smiData.CylindricalJoint(9).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(9).ID = "[Acrylic Frame-4:-:Acrylic Frame-5]";

smiData.CylindricalJoint(10).Rz.Pos = -54.088051885545482;  % deg
smiData.CylindricalJoint(10).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(10).ID = "[Motor 37D-1:-:Wheel Asssembly-1]";

smiData.CylindricalJoint(11).Rz.Pos = -0.64820346241753524;  % deg
smiData.CylindricalJoint(11).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(11).ID = "[PLA Thread Rod Spacer - 45mm-1:-:PLA Thread Rod Spacer - 45mm-2]";


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(18).Rz.Pos = 0.0;
smiData.PlanarJoint(18).Px.Pos = 0.0;
smiData.PlanarJoint(18).Py.Pos = 0.0;
smiData.PlanarJoint(18).ID = "";

smiData.PlanarJoint(1).Rz.Pos = 90.000000000010147;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = "[6x2inBreadboard-1:-:assembly of drv 8833.stp-1]";

smiData.PlanarJoint(2).Rz.Pos = 90.000000000000014;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % mm
smiData.PlanarJoint(2).Py.Pos = 0;  % mm
smiData.PlanarJoint(2).ID = "[6x2inBreadboard-1:-:6mm SPDT Mini Toggle Switch.step-1]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(3).Rz.Pos = -113.29276503197586;  % deg
smiData.PlanarJoint(3).Px.Pos = 0;  % mm
smiData.PlanarJoint(3).Py.Pos = 0;  % mm
smiData.PlanarJoint(3).ID = "[250mm ROD-1:-:250mm ROD-4]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(4).Rz.Pos = 89.058664680215074;  % deg
smiData.PlanarJoint(4).Px.Pos = 0;  % mm
smiData.PlanarJoint(4).Py.Pos = 0;  % mm
smiData.PlanarJoint(4).ID = "[250mm ROD-2:-:250mm ROD-3]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(5).Rz.Pos = -52.624438567070108;  % deg
smiData.PlanarJoint(5).Px.Pos = 0;  % mm
smiData.PlanarJoint(5).Py.Pos = 0;  % mm
smiData.PlanarJoint(5).ID = "[250mm ROD-3:-:250mm ROD-4]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(6).Rz.Pos = 0;  % deg
smiData.PlanarJoint(6).Px.Pos = 0;  % mm
smiData.PlanarJoint(6).Py.Pos = 0;  % mm
smiData.PlanarJoint(6).ID = "[Acrylic Frame-4:-:hex nut_ai-1]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(7).Rz.Pos = 0;  % deg
smiData.PlanarJoint(7).Px.Pos = 0;  % mm
smiData.PlanarJoint(7).Py.Pos = 0;  % mm
smiData.PlanarJoint(7).ID = "[Acrylic Frame-4:-:hex nut_ai-2]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(8).Rz.Pos = 0;  % deg
smiData.PlanarJoint(8).Px.Pos = 0;  % mm
smiData.PlanarJoint(8).Py.Pos = 0;  % mm
smiData.PlanarJoint(8).ID = "[Acrylic Frame-4:-:hex nut_ai-3]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(9).Rz.Pos = 0;  % deg
smiData.PlanarJoint(9).Px.Pos = 0;  % mm
smiData.PlanarJoint(9).Py.Pos = 0;  % mm
smiData.PlanarJoint(9).ID = "[Acrylic Frame-4:-:hex nut_ai-4]";

smiData.PlanarJoint(10).Rz.Pos = -9.1979640164025636;  % deg
smiData.PlanarJoint(10).Px.Pos = 0;  % mm
smiData.PlanarJoint(10).Py.Pos = 0;  % mm
smiData.PlanarJoint(10).ID = "[Acrylic Frame-4:-:pan cross head_am-48]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(11).Rz.Pos = -127.58538261958948;  % deg
smiData.PlanarJoint(11).Px.Pos = 0;  % mm
smiData.PlanarJoint(11).Py.Pos = 0;  % mm
smiData.PlanarJoint(11).ID = "[Acrylic Frame-4:-:PLA Thread Rod Spacer - 45mm-1]";

smiData.PlanarJoint(12).Rz.Pos = 126.93717915717194;  % deg
smiData.PlanarJoint(12).Px.Pos = 0;  % mm
smiData.PlanarJoint(12).Py.Pos = 0;  % mm
smiData.PlanarJoint(12).ID = "[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-3]";

smiData.PlanarJoint(13).Rz.Pos = -90.000000000000014;  % deg
smiData.PlanarJoint(13).Px.Pos = 0;  % mm
smiData.PlanarJoint(13).Py.Pos = 0;  % mm
smiData.PlanarJoint(13).ID = "[Acrylic Frame-5:-:6x2inBreadboard-1]";

smiData.PlanarJoint(14).Rz.Pos = 89.999999999999972;  % deg
smiData.PlanarJoint(14).Px.Pos = 0;  % mm
smiData.PlanarJoint(14).Py.Pos = 0;  % mm
smiData.PlanarJoint(14).ID = "[Motor 37D-1:-:]";

smiData.PlanarJoint(15).Rz.Pos = -1.742061544416226e-14;  % deg
smiData.PlanarJoint(15).Px.Pos = 0;  % mm
smiData.PlanarJoint(15).Py.Pos = 0;  % mm
smiData.PlanarJoint(15).ID = "[6x2inBreadboard-1:-:Arduino Nano 33 IoT.stp-1]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(16).Rz.Pos = 0;  % deg
smiData.PlanarJoint(16).Px.Pos = 0;  % mm
smiData.PlanarJoint(16).Py.Pos = 0;  % mm
smiData.PlanarJoint(16).ID = "[Acrylic Frame-4:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(17).Rz.Pos = 126.93717915717194;  % deg
smiData.PlanarJoint(17).Px.Pos = 0;  % mm
smiData.PlanarJoint(17).Py.Pos = 0;  % mm
smiData.PlanarJoint(17).ID = "[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:PLA Thread Rod Spacer - 45mm-2]";

smiData.PlanarJoint(18).Rz.Pos = 0;  % deg
smiData.PlanarJoint(18).Px.Pos = 0;  % mm
smiData.PlanarJoint(18).Py.Pos = 0;  % mm
smiData.PlanarJoint(18).ID = "[Acrylic Frame-4:-:AA Battery Mock-2]";


%Initialize the PrismaticJoint structure array by filling in null values.
smiData.PrismaticJoint(1).Pz.Pos = 0.0;
smiData.PrismaticJoint(1).ID = "";

smiData.PrismaticJoint(1).Pz.Pos = 0;  % m
smiData.PrismaticJoint(1).ID = "[Acrylic Frame-5:-:Custom Frame - LvL 3 ELEC 391 Project requirement-1]";


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(50).Rz.Pos = 0.0;
smiData.RevoluteJoint(50).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(1).ID = "[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-4]";

smiData.RevoluteJoint(2).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(2).ID = "[PLA Battery Holder - 8xAA Horizontal Position-1:-:hex nut style 1_am-5]";

smiData.RevoluteJoint(3).Rz.Pos = 89.999999999999986;  % deg
smiData.RevoluteJoint(3).ID = "[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-2]";

smiData.RevoluteJoint(4).Rz.Pos = 89.999999999999986;  % deg
smiData.RevoluteJoint(4).ID = "[PLA Battery Holder - 8xAA Horizontal Position-2:-:hex nut style 1_am-3]";

smiData.RevoluteJoint(5).Rz.Pos = 147.29942174191297;  % deg
smiData.RevoluteJoint(5).ID = "[250mm ROD-4:-:hex nut_ai-1]";

smiData.RevoluteJoint(6).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(6).ID = "[Acrylic Frame-4:-:hex nut style 1_am-7]";

smiData.RevoluteJoint(7).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(7).ID = "[Acrylic Frame-4:-:hex nut style 1_am-8]";

smiData.RevoluteJoint(8).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(8).ID = "[Acrylic Frame-4:-:hex nut style 1_am-10]";

smiData.RevoluteJoint(9).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(9).ID = "[Acrylic Frame-4:-:hex nut style 1_am-11]";

smiData.RevoluteJoint(10).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(10).ID = "[Acrylic Frame-4:-:hex nut style 1_am-12]";

smiData.RevoluteJoint(11).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(11).ID = "[Acrylic Frame-4:-:hex nut style 1_am-13]";

smiData.RevoluteJoint(12).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(12).ID = "[Acrylic Frame-4:-:hex nut style 1_am-14]";

smiData.RevoluteJoint(13).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(13).ID = "[Acrylic Frame-4:-:hex nut style 1_am-15]";

smiData.RevoluteJoint(14).Rz.Pos = 90;  % deg
smiData.RevoluteJoint(14).ID = "[Acrylic Frame-4:-:pan cross head_am-45]";

smiData.RevoluteJoint(15).Rz.Pos = 90;  % deg
smiData.RevoluteJoint(15).ID = "[Acrylic Frame-4:-:pan cross head_am-46]";

smiData.RevoluteJoint(16).Rz.Pos = 90;  % deg
smiData.RevoluteJoint(16).ID = "[Acrylic Frame-4:-:pan cross head_am-47]";

smiData.RevoluteJoint(17).Rz.Pos = -127.58538261958948;  % deg
smiData.RevoluteJoint(17).ID = "[Acrylic Frame-5:-:PLA Thread Rod Spacer - 45mm-1]";

smiData.RevoluteJoint(18).Rz.Pos = -1.9083328088781094e-14;  % deg
smiData.RevoluteJoint(18).ID = "[Motor 37D-1:-:pan cross head_am-12]";

smiData.RevoluteJoint(19).Rz.Pos = -1.9083328088781094e-14;  % deg
smiData.RevoluteJoint(19).ID = "[Motor 37D-1:-:pan cross head_am-13]";

smiData.RevoluteJoint(20).Rz.Pos = -1.9083328088781094e-14;  % deg
smiData.RevoluteJoint(20).ID = "[Motor 37D-1:-:pan cross head_am-14]";

smiData.RevoluteJoint(21).Rz.Pos = -1.9083328088781094e-14;  % deg
smiData.RevoluteJoint(21).ID = "[Motor 37D-1:-:pan cross head_am-15]";

smiData.RevoluteJoint(22).Rz.Pos = 179.99999999999997;  % deg
smiData.RevoluteJoint(22).ID = "[Motor 37D-3:-:pan cross head_am-16]";

smiData.RevoluteJoint(23).Rz.Pos = 179.99999999999997;  % deg
smiData.RevoluteJoint(23).ID = "[Motor 37D-3:-:pan cross head_am-17]";

smiData.RevoluteJoint(24).Rz.Pos = 179.99999999999997;  % deg
smiData.RevoluteJoint(24).ID = "[Motor 37D-3:-:pan cross head_am-18]";

smiData.RevoluteJoint(25).Rz.Pos = 179.99999999999997;  % deg
smiData.RevoluteJoint(25).ID = "[Motor 37D-3:-:pan cross head_am-19]";

smiData.RevoluteJoint(26).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(26).ID = "[:-:pan cross head_am-20]";

smiData.RevoluteJoint(27).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(27).ID = "[:-:pan cross head_am-22]";

smiData.RevoluteJoint(28).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(28).ID = "[:-:pan cross head_am-23]";

smiData.RevoluteJoint(29).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(29).ID = "[:-:pan cross head_am-25]";

smiData.RevoluteJoint(30).Rz.Pos = -112.44828084682671;  % deg
smiData.RevoluteJoint(30).ID = "[:-:pan cross head_am-26]";

smiData.RevoluteJoint(31).Rz.Pos = -112.44828084682671;  % deg
smiData.RevoluteJoint(31).ID = "[:-:pan cross head_am-28]";

smiData.RevoluteJoint(32).Rz.Pos = -112.44828084682671;  % deg
smiData.RevoluteJoint(32).ID = "[:-:pan cross head_am-29]";

smiData.RevoluteJoint(33).Rz.Pos = -112.44828084682671;  % deg
smiData.RevoluteJoint(33).ID = "[:-:pan cross head_am-31]";

smiData.RevoluteJoint(34).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(34).ID = "[Motor 37D-3:-:pan cross head_am-33]";

smiData.RevoluteJoint(35).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(35).ID = "[Motor 37D-3:-:pan cross head_am-34]";

smiData.RevoluteJoint(36).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(36).ID = "[Motor 37D-3:-:pan cross head_am-35]";

smiData.RevoluteJoint(37).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(37).ID = "[Motor 37D-3:-:pan cross head_am-36]";

smiData.RevoluteJoint(38).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(38).ID = "[Motor 37D-3:-:pan cross head_am-37]";

smiData.RevoluteJoint(39).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(39).ID = "[Motor 37D-3:-:pan cross head_am-38]";

smiData.RevoluteJoint(40).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(40).ID = "[Motor 37D-1:-:pan cross head_am-39]";

smiData.RevoluteJoint(41).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(41).ID = "[Motor 37D-1:-:pan cross head_am-40]";

smiData.RevoluteJoint(42).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(42).ID = "[Motor 37D-1:-:pan cross head_am-41]";

smiData.RevoluteJoint(43).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(43).ID = "[Motor 37D-1:-:pan cross head_am-42]";

smiData.RevoluteJoint(44).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(44).ID = "[Motor 37D-1:-:pan cross head_am-43]";

smiData.RevoluteJoint(45).Rz.Pos = -157.55171915317328;  % deg
smiData.RevoluteJoint(45).ID = "[Motor 37D-1:-:pan cross head_am-44]";

smiData.RevoluteJoint(46).Rz.Pos = 16.673589908970957;  % deg
smiData.RevoluteJoint(46).ID = "[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-5]";

smiData.RevoluteJoint(47).Rz.Pos = -109.18957023107404;  % deg
smiData.RevoluteJoint(47).ID = "[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-6]";

smiData.RevoluteJoint(48).Rz.Pos = -109.18957023107404;  % deg
smiData.RevoluteJoint(48).ID = "[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-7]";

smiData.RevoluteJoint(49).Rz.Pos = -109.18957023107404;  % deg
smiData.RevoluteJoint(49).ID = "[Custom Frame - LvL 3 ELEC 391 Project requirement-1:-:hex nut_ai-8]";

smiData.RevoluteJoint(50).Rz.Pos = 169.66043383644183;  % deg
smiData.RevoluteJoint(50).ID = "[PLA Battery Holder - 8xAA Horizontal Position-2:-:PLA Puser - 8xAA Battery Holder-1]";

